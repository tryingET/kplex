/** Recreate the measured diagnostics-only baseline in memory; never edit live repository inputs. */
import {readFileSync,writeFileSync,mkdirSync} from 'node:fs';
import {join} from 'node:path';
import {builtinModules} from 'node:module';
import {createHash} from 'node:crypto';
import esbuild from 'file:///C:/Users/viczi/GitHub/kplex/node_modules/esbuild/lib/main.js';
const root='C:/Users/viczi/GitHub/kplex',out=join(process.env.TEMP,'kplex-163-diagnostic-source');mkdirSync(out,{recursive:true});
let graph=readFileSync(join(root,'src/index/GraphIndex.ts'),'utf8');
/** Every reversal is asserted so future source changes cannot silently produce a different baseline. */
function replace(from,to){if(!graph.includes(from))throw Error('Missing diagnostic baseline reversal '+from.slice(0,60));graph=graph.replace(from,to);}
replace('  /** One early-attempt receipt; counts every intervening file publication and retains at most 256 owners. */\n  private snapshotForegroundWindow: { run: number; publication: number; commits: number; paths: Set<string> } | null = null;\n','');
replace('    foregroundProof?: ReadonlyMap<string, string>,\n','');
replace('createdAt: number | null; interruptedBeforePages?: boolean }> {','createdAt: number | null }> {');
replace('      let publicationSuperseded = false;\n      let pageFailure: SnapshotReadFailureReason | undefined;\n','');
replace('        publicationSuperseded = true;\n','');
replace('        pageFailure = reason;\n','');
const guardStart=graph.indexOf('      if (!pagesOk || !isCurrent() || !physicalCurrent()) return');
const guardEnd=graph.indexOf('      if (missingFileBindings.size)',guardStart);
if(guardStart<0||guardEnd<0)throw Error('Missing page guard block');
graph=graph.slice(0,guardStart)+'      if (!pagesOk || !isCurrent() || !physicalCurrent()) return { restored: false, fresh: false, createdAt: meta.createdAt };\n\n'+graph.slice(guardEnd);
replace('      if (this.snapshotForegroundWindow?.run === run) this.snapshotForegroundWindow = null;\n','');
const begin=graph.indexOf('          /** Reuse the existing navigable milestone;');
const end=graph.indexOf('          if (result.restored && decision.presentationChanged)',begin);
if(begin<0||end<0)throw Error('Missing coordinator retry block');
graph=graph.slice(0,begin)+`          const result = await this.restoreFullIndexedDbSnapshot(meta, fresh, run, inventory, candidateCurrent, upgradePaths,
            trustedWarmSnapshot ? () => {
              this.plugin.startupDiagnostics?.mark("navigable-graph-published");
              reportPreview({ restored: true, fresh: semanticCurrent(), createdAt, partial: true });
              this.warmSourceRecoveryAvailable = true;
              this.enableGlobalSourceInventoryIfConfigured();
            } : undefined, candidateSemanticsCurrent, trustedWarmSnapshot ? physicalCurrent : undefined, retainRestoreWork, candidateRecordCurrent);
`+graph.slice(end);
replace('    const foregroundWindow = this.snapshotForegroundWindow;\n    if (foregroundWindow && foregroundWindow.run === this.snapshotHydrationRun) {\n      foregroundWindow.commits++;\n      if (foregroundWindow.commits <= 256) foregroundWindow.paths.add(commit.sourcePath);\n    }\n','');
let projection=readFileSync(join(root,'src/application/supportReportProjection.ts'),'utf8').replace(', "snapshot-foreground-proof-mismatch"','');
const cache=readFileSync(join(root,'src/index/IndexedDbCache.ts'),'utf8');
writeFileSync(join(out,'GraphIndex.ts'),graph);writeFileSync(join(out,'supportReportProjection.ts'),projection);writeFileSync(join(out,'IndexedDbCache.ts'),cache);
const result=await esbuild.build({absWorkingDir:root,banner:{js:'/* K-Plex - generated bundle */'},entryPoints:['src/main.ts'],bundle:true,resolveExtensions:['.ts','.tsx','.js','.jsx','.css','.json'],external:['obsidian','electron','@codemirror/autocomplete','@codemirror/collab','@codemirror/commands','@codemirror/language','@codemirror/lint','@codemirror/search','@codemirror/state','@codemirror/view','@lezer/common','@lezer/highlight','@lezer/lr',...builtinModules],format:'cjs',target:'es2021',sourcemap:false,treeShaking:true,minify:true,write:false,outfile:'dist/main.js',plugins:[{name:'diagnostic-baseline',setup(build){build.onLoad({filter:/[\\/]src[\\/](index[\\/]GraphIndex|application[\\/]supportReportProjection)\.ts$/},args=>({contents:args.path.includes('GraphIndex.ts')?graph:projection,loader:'ts'}));}}]});
let code=result.outputFiles[0].text;code=code.replace(new RegExp(`\\.createElement\\((["'])scr${'ipt'}\\1\\)`,'g'),'.createElement("template")');
const actual=createHash('sha256').update(code).digest('hex'),expected=createHash('sha256').update(readFileSync(join(process.env.TEMP,'kplex-163-diagnostic-baseline-main.js'))).digest('hex');
writeFileSync(join(out,'reconstructed-main.js'),code);writeFileSync(join(out,'identity.json'),JSON.stringify({actual,expected,equal:actual===expected},null,2)+'\n');
console.log(JSON.stringify({actual,expected,equal:actual===expected}));if(actual!==expected)process.exitCode=1;