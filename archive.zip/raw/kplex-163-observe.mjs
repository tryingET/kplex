/** Capture aggregate startup diagnostics only: no note APIs, source/cache reads, reloads, or vault writes. */
import {readFileSync,mkdirSync,writeFileSync} from 'node:fs';
import {createHash} from 'node:crypto';
import {join,resolve,relative,isAbsolute} from 'node:path';
import {obsidianCliExecutable,spawnNativeSync} from 'file:///C:/Users/viczi/GitHub/kplex/scripts/testing/obsidian/processTools.mjs';
const vault=process.argv[2]??"Zsolt's Brain",out=join(process.env.TEMP,'kplex-163-observations');mkdirSync(out,{recursive:true});
/** Transport only the explicit named-vault diagnostic; never echo arbitrary host stdout/errors. */
function cli(command,...args){const r=spawnNativeSync(obsidianCliExecutable(),[`vault=${vault}`,command,...args],{encoding:'utf8',timeout:30000,killSignal:'SIGKILL',maxBuffer:2*1024*1024});if(r.error||r.status!==0||/^Error:/m.test(r.stdout))throw Error('Named-vault diagnostic transport failed');return r.stdout.trim();}
const vaultRoot=resolve(cli('vault','info=path').replace(/^path\s+/,''));
const code=String.raw`(()=>{try{
 const p=app.plugins.plugins['k-plex'];if(!p?.index)return JSON.stringify({available:false});
 const i=p.index,s=p.getIndexStatus(),h=i.getSnapshotHydrationDiagnostics(),d=p.getStartupDiagnostics?.();
 const numbers=(value,keys)=>Object.fromEntries(keys.map(key=>[key,Number.isFinite(value?.[key])?value[key]:null]));
 const reasons=['complete-snapshot-fresh','complete-snapshot-stale','complete-restored','source-backed-physical-baseline','startup-host-wave-cached-presentation','folder-structure-changed','hydration-incomplete','restore-exception','hydration-stalled','complete-saved','startup-source-authority-pending'];
 const phases=['idle','metadata','preview','source-authority','requested-semantics','node-vocabulary','pages','file-rebind','relations','preview-search','evidence','resolve','authoritative-search','promote','complete','failed','timed-out','cancelled'];
 const saved=i.getSavedSnapshotSummary(),safeMeta=value=>value?numbers(value,['createdAt','schema']):null;
 const win=require('@electron/remote').getCurrentWindow();
 return JSON.stringify({available:true,configDir:app.vault.configDir,at:Date.now(),host:{versions:{node:process.versions.node,electron:process.versions.electron,chrome:process.versions.chrome},hidden:document.hidden,documentFocused:document.hasFocus(),windowFocused:win.isFocused(),backgroundThrottling:win.webContents.getBackgroundThrottling()},
 mode:{onDemand:i.isOnDemandMode(),urlEnabled:p.settings.indexUrls,throttle:p.settings.indexingThrottle},
 status:{upToDate:!!s.upToDate,phase:['ready','updating','preparing','paused','error'].includes(s.phase)?s.phase:'other',...numbers(s,['indexedFiles','totalFiles'])},
 graph:{nodes:i.size,publishedMarkdownFiles:i.indexedMarkdownFileCount(),fullSnapshotHydrated:i.isFullSnapshotHydrated(),sourceBacked:!!i.sourceBackedStartup,sourceVocabularyPublished:!!i.sourceNodeVocabularyPublished,fingerprints:i.semanticFingerprints?.size},
 hydration:{...numbers(h,['run','startedAt','phaseStartedAt','lastProgressAt','pages','relations','evidence']),phase:phases.includes(h.phase)?h.phase:'other',lastActivePhase:phases.includes(h.lastActivePhase)?h.lastActivePhase:'other',outcome:['idle','running','complete','failed','timed-out','cancelled'].includes(h.outcome)?h.outcome:'other'},
 saved:{available:saved.storage==='available',invalidActive:!!saved.invalidActive,active:safeMeta(saved.active),checkpoint:safeMeta(saved.checkpoint)},
 source:numbers(i.getSourceAcquisitionCounters?.(),['checked','reusedBodies','legacyBodies','vaultReads','parses','repaired','resolutionRefreshes','pendingMetadata','failures']),
 revisions:{publication:i.publicationRevision,source:p.getIndexSourceRevision(),policy:i.semanticPolicyRevision},
 timing:{enabled:!!d?.enabled,frozen:!!d?.frozen,startedAtMs:d?.startedAtMs,phases:(d?.phases??[]).slice(-24).map(row=>({lane:['source','hydration'].includes(row.lane)?row.lane:'other',phase:phases.includes(row.phase)?row.phase:'other',...numbers(row,['pass','processed','total','startedMs','endedMs'])}))},
 decisions:i.getIndexDiagnostics().slice(-20).map(row=>({...numbers(row,['at','added','removed','modified','durationMs']),reason:reasons.includes(row.reason)?row.reason:'other'}))});
 }catch{return JSON.stringify({available:false,errorCode:'aggregate-diagnostics-unavailable'});}})()`;
const raw=cli('eval',`code=${code}`);let observation;
try{observation=JSON.parse(raw.slice(raw.indexOf('{')));}catch{throw Error('Invalid aggregate diagnostic response');}
if(!observation.available)throw Error('Aggregate startup diagnostics unavailable');
const config=resolve(vaultRoot,observation.configDir);const inside=relative(vaultRoot,config);if(!inside||inside.startsWith('..')||isAbsolute(inside))throw Error('Config directory outside selected vault');
delete observation.configDir;
const artifacts=Object.fromEntries(['main.js','manifest.json','styles.css'].map(name=>[name,createHash('sha256').update(readFileSync(join(config,'plugins','k-plex',name))).digest('hex')]));
const receipt={label:vault==="Zsolt's Brain"?'personal-startup-observation':'disposable-startup-observation',noteContentAccess:false,vaultWrites:false,artifacts,observation};
const file=join(out,receipt.label+'-'+Date.now()+'.json');writeFileSync(file,JSON.stringify(receipt,null,2)+'\n');
console.log(JSON.stringify({file,...receipt}));
