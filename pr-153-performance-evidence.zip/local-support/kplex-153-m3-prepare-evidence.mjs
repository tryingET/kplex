/** Prepare aggregate native analysis/audit with unchanged accepted B5 runtime and explicit A baseline. */
import assert from 'node:assert/strict';
import {readFileSync,writeFileSync,mkdirSync} from 'node:fs';
import {join} from 'node:path';
import {tmpdir} from 'node:os';
const temp=tmpdir(),raw='docs/validation/indexing-native-url-aggregate-2026-10-14';mkdirSync(raw,{recursive:true});
let analysis=readFileSync(join(temp,'kplex-153-b5-runtime-analysis.mjs'),'utf8').replace("raw='docs/validation/indexing-url-adjacency-storage-2026-10-14'",`raw='${raw}'`).replaceAll('kplex-153-b5-runtime-${mode}','kplex-153-m3-${mode}');
analysis=analysis.replace('pair<=3;pair++)for(const version',"pair<=(mode==='retained'?5:3);pair++)for(const version");assert(analysis.includes("mode==='retained'?5:3"));
writeFileSync(join(temp,'kplex-153-m3-analysis.mjs'),analysis);
let audit=readFileSync(join(temp,'kplex-153-b5-runtime-audit.mjs'),'utf8').replace("raw='docs/validation/indexing-url-adjacency-storage-2026-10-14'",`raw='${raw}'`);
audit=audit.replace("'docs/validation/indexing-url-search-publication-2026-10-14/environment-and-sources.json'","'docs/validation/indexing-url-adjacency-storage-2026-10-14/environment-and-sources.json'");
audit=audit.replace("&&file!=='src/index/UrlAdjacencyMap.ts'",'');
audit=audit.replace("baseline:'3ef54e2',candidateRuntime:'B5 exact source/artifact hashes'","baseline:'a162044',candidateRuntime:'cacefe5 unchanged'").replace('runtimeUnchanged:false','runtimeUnchanged:true');
audit=audit.replace("fullVerification:'host-verification.json'","fullVerificationReused:'../indexing-url-adjacency-storage-2026-10-14/host-verification.json'");
audit=audit.replace("baselineFullVerification:'indexing-url-search-publication-2026-10-14/host-verification.json'","baselineFullVerification:'indexing-hydration-2026-10-13/host.json'");
audit=audit.replace("['kplex-153-b5-runtime-retained-pairs.mjs','kplex-153-b5-runtime-unforced-pairs.mjs','kplex-153-b5-runtime-analysis.mjs','kplex-153-b5-runtime-evidence.mjs','kplex-153-b2-restage.mjs']","['kplex-153-m3-retained-pairs.mjs','kplex-153-m3-unforced-pairs.mjs','kplex-153-m3-replay-pairs.mjs','kplex-153-m3-prepare-runners.mjs','kplex-153-m3-analysis.mjs','kplex-153-m3-prepare-evidence.mjs','kplex-153-b2-restage.mjs']");
audit=audit.replace('Matched retained/unforced diagnostic conditions separate; Final full-suite/exact native verification separate;', 'Aggregate A/B5 retained/unforced/low-instrumentation replay conditions separate; unchanged B5 full verification reused, no new suite run;');
writeFileSync(join(temp,'kplex-153-m3-audit.mjs'),audit);
console.log(JSON.stringify({raw,analysis:'prepared for five retained/three unforced pairs',audit:'all production sources must match accepted B5'}));
