/** Validate aggregate report provenance and summarize prespecified native conditions without blending measurements. */
import assert from 'node:assert/strict';
import {readFileSync,writeFileSync,readdirSync,existsSync} from 'node:fs';
import {join,dirname,resolve} from 'node:path';
import {tmpdir} from 'node:os';
import {createHash} from 'node:crypto';
import {execFileSync} from 'node:child_process';
const raw='docs/validation/indexing-native-url-aggregate-2026-10-14',ledgerPath=join(raw,'environment-and-sources.json'),ledger=JSON.parse(readFileSync(ledgerPath,'utf8'));
/** Keep median/range descriptive; the complete ordered samples remain in their native receipts. */
const describe=values=>{const sorted=[...values].sort(/** Numeric timing/byte order. */(a,b)=>a-b);return{values,median:sorted[Math.floor(sorted.length/2)],minimum:sorted[0],maximum:sorted.at(-1)};};
/** Hash exact committed/checkout bytes rather than infer a source identity from a version string. */
const hash=value=>createHash('sha256').update(value).digest('hex');
assert.equal(execFileSync('git',['diff','HEAD','--','src'],{encoding:'utf8'}),'');
const memory=JSON.parse(readFileSync(join(raw,'matched-analysis.json'),'utf8')),replay=JSON.parse(readFileSync(join(raw,'replay-analysis.json'),'utf8')).rows,metrics={};
assert.equal(memory.length,16);assert.equal(replay.length,6);
for(const version of ['baseline','candidate']){
  const retained=memory.filter(/** Exact prespecified retained sample group. */row=>row.mode==='retained'&&row.version===version),unforced=memory.filter(/** Unforced pauses do not use pre-replay collection. */row=>row.mode==='unforced'&&row.version===version),timing=replay.filter(/** Only second unwrapped replay lifetimes supply elapsed samples. */row=>row.version===version);
  assert.equal(retained.length,5);assert.equal(unforced.length,3);assert.equal(timing.length,3);
  metrics[version]={retainedBytes:describe(retained.map(/** Already collected live-minus-empty graph deltas. */row=>row.retainedBytes)),retainedMaxFlushMs:describe(retained.map(/** Keep GC-conditioned pause results separate. */row=>row.maxFlush.durationMs)),unforcedMaxFlushMs:describe(unforced.map(/** Per-run largest actual flush. */row=>row.maxFlush.durationMs)),unforcedMaxGapMs:describe(unforced.map(/** Per-run maximum heartbeat is not an interaction percentile. */row=>row.heartbeatMaxMs)),lowInstrumentationElapsedMs:describe(timing.map(/** Independent unwrapped lifetime API duration. */row=>row.elapsedMs)),countedWorkingEntries:timing.map(/** Actual selected-origin iteration work from the separate counted lifetime. */row=>row.workingEntries)};
}
writeFileSync(join(raw,'metrics.json'),JSON.stringify(metrics,null,2)+'\n');
ledger.baselineSources={};for(const file of ['src/index/GraphIndex.ts','src/index/GraphBuilder.ts','src/core/graph/compiler.ts','src/core/graph/evidence.ts','src/index/IndexedDbCache.ts'])ledger.baselineSources[file]=hash(execFileSync('git',['show',`a162044:${file}`],{encoding:'utf8'}));
ledger.driverSources={};for(const file of ['scripts/testing/obsidian/largeUrlReplay.mjs','scripts/testing/obsidian/largeUrlMemory.mjs','scripts/testing/obsidian/controlledProbe.mjs'])ledger.driverSources[file]=hash(readFileSync(file));
ledger.verification={runtimeUnchanged:true,newFullSuiteRun:false,acceptedCandidate:'cacefe5',retainedPairs:5,unforcedPairs:3,dualLifetimeReplayPairs:3,totalNativeLifetimes:28,exactArtifactStages:22,candidateFullVerification:'../indexing-url-adjacency-storage-2026-10-14/host-verification.json'};
for(const file of ['kplex-153-m3-replay-analysis.mjs','kplex-153-m3-final-checks.mjs'])ledger.helperSources[file]=hash(readFileSync(join(tmpdir(),file)));
writeFileSync(ledgerPath,JSON.stringify(ledger,null,2)+'\n');
let json=0;for(const file of readdirSync(raw))if(file.endsWith('.json')){JSON.parse(readFileSync(join(raw,file),'utf8'));json++;}
let links=0;for(const match of readFileSync(raw+'.md','utf8').matchAll(/\]\(([^)]+)\)/g)){if(/^(https?:|#)/.test(match[1]))continue;assert(existsSync(resolve(dirname(raw+'.md'),decodeURIComponent(match[1].split('#')[0]))),match[1]);links++;}
console.log(JSON.stringify({checks:'passed',json,links,metrics}));
