/** Validate B4's frozen-source evidence, local report links and receipt JSON before authorized delivery. */
import assert from 'node:assert/strict';
import {readFileSync,writeFileSync,readdirSync,existsSync} from 'node:fs';
import {dirname,resolve,join} from 'node:path';
import {createHash} from 'node:crypto';
const raw='docs/validation/indexing-url-search-publication-2026-10-14',ledgerPath=join(raw,'environment-and-sources.json'),ledger=JSON.parse(readFileSync(ledgerPath,'utf8'));
/** Record exact executable/test inputs; hashes are checked independently against the measured runtime below. */
const hash=file=>createHash('sha256').update(readFileSync(file)).digest('hex');
assert.equal(hash('src/index/GraphIndex.ts'),'31a9d5fe615a7febf6b514d7c1233d956aa112305341d666944c0a0474fdaa37');
ledger.validationInputs={};for(const file of ['package.json','tests/support/urlPublicationFixture.mjs','tests/support/urlSearchPublicationProbe.mjs','tests/url-search-publication.test.mjs','scripts/testing/url-search-publication-work.mjs'])ledger.validationInputs[file]=hash(file);
ledger.verification={fullExitCode:0,architecture:7,core:128,normal:822,ui:63,portableSources:334,browser:495,focused:10,workCells:5,foregroundCases:6,nativePairs:6,nativeReplays:12,lint:'passed',productionBuild:'passed',nativeSmoke:'passed'};
writeFileSync(ledgerPath,JSON.stringify(ledger,null,2)+'\n');
let json=0;for(const name of readdirSync(raw))if(name.endsWith('.json')){JSON.parse(readFileSync(join(raw,name),'utf8'));json++;}
const report=raw+'.md';let links=0;for(const match of readFileSync(report,'utf8').matchAll(/\]\(([^)]+)\)/g)){const target=match[1];if(/^(https?:|#)/.test(target))continue;assert(existsSync(resolve(dirname(report),decodeURIComponent(target.split('#')[0]))),'Missing local report link: '+target);links++;}
const work=JSON.parse(readFileSync(join(raw,'work-comparison.json'),'utf8'));assert.equal(work.candidate.sourceHash,ledger.sources['src/index/GraphIndex.ts']);
const full=JSON.parse(readFileSync(join(raw,'host-verification.json'),'utf8'));assert.equal(full.status,'passed');assert.deepEqual(full.artifacts.sourceHashes,ledger.artifacts);
console.log(JSON.stringify({json,links,sourceHash:ledger.sources['src/index/GraphIndex.ts'],artifacts:ledger.artifacts,checks:'passed'}));
