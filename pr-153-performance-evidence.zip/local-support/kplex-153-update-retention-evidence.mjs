/** Preserve native retention setup/final receipts and independently verify exact function/runtime identities and bounds. */
import assert from 'node:assert/strict';
import {readFileSync,writeFileSync,copyFileSync,mkdirSync} from 'node:fs';
import {join} from 'node:path';
import {pathToFileURL} from 'node:url';
import {tmpdir,release,cpus,totalmem} from 'node:os';
import {createHash} from 'node:crypto';
import {runInNewContext} from 'node:vm';
import {execFileSync} from 'node:child_process';
const temp=tmpdir(),root=process.cwd(),raw='docs/validation/indexing-url-update-retention-2026-10-14';mkdirSync(raw,{recursive:true});
/** Exact source/function hashes identify diagnostics independently of native receipt claims. */
const hash=value=>createHash('sha256').update(value).digest('hex');
const {nativeUrlFixture}=await import(pathToFileURL(join(root,'scripts/testing/obsidian/nativeUrlFixture.mjs')));
const finalSource=readFileSync('scripts/testing/obsidian/urlUpdateRetention.mjs','utf8'),preliminarySource=readFileSync(join(temp,'kplex-153-url-update-retention-preliminary.mjs'),'utf8');
/** Extract only a definition; evaluating it for toString never executes a native scenario. */
const scenarioHash=source=>hash(runInNewContext(source.slice(source.indexOf('async function scenario'),source.lastIndexOf('\nconst cycles='))+';scenario.toString()'));
const cases=[['kplex-153-update-retention-pilot',2,'setup-pilot.json',preliminarySource],['kplex-153-update-retention-final',64,'preliminary-64.json',preliminarySource],['kplex-153-update-retention-complete',64,'final-64.json',finalSource]];
for(const[folder,cycles,target,source]of cases){const report=JSON.parse(readFileSync(join(temp,folder,'url-update-retention.json'),'utf8'));assert.equal(report.status,'passed');assert.equal(report.cleanup,'passed');assert.equal(report.driver.scenario,scenarioHash(source));assert.equal(report.driver.definitions,hash(`const retentionCycles=${cycles};const nativeUrlFixture=${nativeUrlFixture.toString()};`));assert.equal(report.result.cycles,cycles);assert.equal(report.result.indexCollected,true);assert.deepEqual(report.result.operations,{reads:cycles,parses:cycles});for(const sample of report.result.samples){assert.equal(sample.pages,514);assert.equal(sample.declarations,1024);assert.equal(sample.publishedTargets,514);assert.equal(sample.originDepth,0);assert.equal(sample.originRetainedEntries,512);assert.equal(sample.livePublishedMaps,1);assert.equal(sample.observedPublishedMaps,sample.step+1);}copyFileSync(join(temp,folder,'url-update-retention.json'),join(raw,target));}
copyFileSync(join(temp,'kplex-153-url-update-retention-preliminary.mjs'),join(raw,'preliminary-driver.txt'));
const final=JSON.parse(readFileSync(join(raw,'final-64.json'),'utf8'));assert.equal(final.result.liveDisposedPublishedMaps,0);assert.equal(final.result.samples.length,9);
const audit=JSON.parse(readFileSync(join(temp,'kplex-153-update-retention-audit/url-update-retention-audit.json'),'utf8'));assert.equal(audit.status,'passed');assert.equal(audit.cleanup,'passed');assert.equal(audit.result.ownedRows,0);assert.equal(audit.result.markdown,88);assert.equal(audit.result.files,106);assert.equal(audit.result.debuggerAttached,false);copyFileSync(join(temp,'kplex-153-update-retention-audit/url-update-retention-audit.json'),join(raw,'cleanup-audit.json'));
const accepted=JSON.parse(readFileSync('docs/validation/indexing-url-adjacency-storage-2026-10-14/environment-and-sources.json','utf8'));
assert.equal(execFileSync('git',['diff','HEAD','--','src'],{encoding:'utf8'}),'');
for(const report of [final,audit])assert.deepEqual(report.artifacts,accepted.artifacts);
const sources={};for(const file of Object.keys(accepted.sources))if(file.startsWith('src/')){sources[file]=hash(readFileSync(file));assert.equal(sources[file],accepted.sources[file]);}
for(const file of ['scripts/testing/obsidian/urlUpdateRetention.mjs','scripts/testing/obsidian/nativeUrlFixture.mjs','scripts/testing/obsidian/controlledProbe.mjs','scripts/testing/obsidian/processTools.mjs'])sources[file]=hash(readFileSync(file));
for(const vault of ['kplex-test-small','kplex-test'])for(const[name,value]of Object.entries(accepted.artifacts))assert.equal(hash(readFileSync(`C:/Obsidian/${vault}/.obsidian/plugins/k-plex/${name}`)),value);
const samples=final.result.samples,last=samples.at(-1),warm=samples.find(/** Prespecified first post-eight-revision sample, not a retrospectively chosen minimum. */row=>row.step===8);
writeFileSync(join(raw,'analysis.json'),JSON.stringify({cycles:64,samples,initialToFinalRendererBytes:last.usedBytes-samples[0].usedBytes,step8To64RendererBytes:last.usedBytes-warm.usedBytes,afterDisposalRendererBytes:final.result.disposedHeapBytes,indexCollected:true,liveDisposedPublishedMaps:0,limits:'Whole renderer includes Obsidian and primary index activity. Structural/weak collection bounds, not isolated private-index bytes, timing, process peak or hours-long/mobile acceptance.'},null,2)+'\n');
writeFileSync(join(raw,'environment-and-sources.json'),JSON.stringify({at:new Date().toISOString(),node:process.version,os:`${process.platform} ${release()}`,cpu:cpus()[0].model,memoryBytes:totalmem(),measurementBase:execFileSync('git',['rev-parse','HEAD'],{encoding:'utf8'}).trim(),candidateRuntime:'cacefe5 unchanged',runtimeUnchanged:true,artifacts:accepted.artifacts,sources,fullVerificationReused:'../indexing-url-adjacency-storage-2026-10-14/host-verification.json',primaryAndFixtureCleanup:'Native final and independent read-only audit pass; shared fixture restores its captured geometry. No serialized before/after workspace comparison was captured.',limitations:'M3 residual heap/flush tradeoff still awaits maintainer decision; no additional full-suite run or physical-device/hours-long/processpeak claim.'},null,2)+'\n');
console.log(JSON.stringify({receipts:3,audit:'passed',cycles:64,bodyOperations:final.result.operations,observedMaps:65,liveMapsAtEpochs:1,liveMapsAfterDisposal:0,rendererDelta:last.usedBytes-samples[0].usedBytes,warmEpochDelta:last.usedBytes-warm.usedBytes,source:hash(finalSource)}));
