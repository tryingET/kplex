/**
 * Native #153 retained-heap/unload and display-flush diagnostic over the shared20k fixture.
 * Forced GC is outside replay and changes allocation conditions: these are diagnostic runs,
 * not replacements for the low-instrumentation elapsed comparison. Only aggregate heap/GC
 * facts and eight heartbeat gaps are retained. Owns its debugger/observer; the shared fixture
 * independently owns index/cache/window cleanup. No heap snapshots or vault contents are saved.
 */
import {runControlledProbe} from './controlledProbe.mjs';
import {largeUrlReplayScenario} from './largeUrlReplay.mjs';

/** Measure a single real replay, then release all fixture roots before testing WeakRef collection. */
async function scenario(app,c){
  const win=require('@electron/remote').getCurrentWindow(),debug=win.webContents.debugger;
  const hooks=require('node:perf_hooks'),gc=[],weak=[],memory={};let owned=false,observer,dropped=0,clockOffset=0;
  /** Missing capabilities fail the diagnostic rather than substituting unforced heap samples. */
  const check=(value,message)=>{if(!value)throw Error(message);};
  /** Bound every diagnostic command and retire its timeout independently of command success. */
  const command=async(method,parameters)=>{let timer;try{return await Promise.race([parameters===undefined?debug.sendCommand(method):debug.sendCommand(method,parameters),new Promise(/** This timer belongs only to one CDP command. */(_,reject)=>{timer=window.setTimeout(/** Never let an unavailable debugger hold the controller indefinitely. */()=>reject(Error('CDP command deadline: '+method)),20000);})]);}finally{if(timer!==undefined)window.clearTimeout(timer);}};
  /** Release the current renderer task so completed async frames and WeakRef keep-alive jobs end. */
  const task=()=>new Promise(/** Own one short diagnostic yield. */done=>window.setTimeout(done,50));
  /** Keep bounded GC intervals using Node's native performance clock, with no heap object retention. */
  const record=entries=>{for(const entry of entries){if(gc.length>=1024){dropped++;continue;}gc.push({startEpoch:hooks.performance.timeOrigin+entry.startTime+clockOffset,durationMs:entry.duration,kind:entry.detail?.kind,flags:entry.detail?.flags});}};
  /** Force collection only at an untimed lifecycle boundary; process metrics are current KB, not peak. */
  const snapshot=async label=>{c.progress={phase:label};await task();const collectionStartedEpoch=performance.timeOrigin+performance.now();await command('HeapProfiler.collectGarbage');await task();record(observer.takeRecords());const heap=await command('Runtime.getHeapUsage'),processMemoryKb=await process.getProcessMemoryInfo();check(Number.isFinite(heap.usedSize),'Native CDP heap bytes');return{heap,processMemoryKb,collectionStartedEpoch,atEpoch:performance.timeOrigin+performance.now()};};
  try{
    check(app.vault.getName()==='kplex-test','Authorized large vault required');
    check(!debug.isAttached(),'Another debugger already owns this native renderer');debug.attach('1.3');owned=true;
    const identity=await command('Runtime.evaluate',{expression:'window.app?.vault?.getName()',returnByValue:true});check(!identity.exceptionDetails&&identity.result?.value===app.vault.getName(),'CDP default realm must be this exact vault');
    check(hooks.PerformanceObserver.supportedEntryTypes.includes('gc'),'Native GC observation available');
    const clockBefore=performance.timeOrigin+performance.now(),nodeEpoch=hooks.performance.timeOrigin+hooks.performance.now(),clockAfter=performance.timeOrigin+performance.now();clockOffset=(clockBefore+clockAfter)/2-nodeEpoch;memory.clock={offsetMs:clockOffset,readSpanMs:clockAfter-clockBefore};c.progress={phase:'clock-calibration',clock:memory.clock};check(memory.clock.readSpanMs<5&&Number.isFinite(clockOffset),'Bounded native clock calibration');
    observer=new hooks.PerformanceObserver(/** Forward only aggregate collection intervals. */list=>record(list.getEntries()));observer.observe({entryTypes:['gc']});
    c.trials=[false];c.flushDiagnostics=true;
    c.memory={
      /** The empty installed index/cache is prepared; collection precedes the measured API. */
      async beforeRestore(){memory.before=await snapshot('gc-before-restore');check(gc.some(/** Prove observation of this renderer collection rather than an unrelated earlier event. */entry=>entry.startEpoch>=memory.before.collectionStartedEpoch&&entry.startEpoch<=memory.before.atEpoch),'Forced renderer GC must be visible to the native GC observer');},
      /** Capture graph ownership weakly; keeping the live graph is deliberate at this boundary. */
      async afterRestore(index){for(const[name,value]of Object.entries({index,cache:index.indexedDb,workingPages:index.urlState.pages,workingEvidence:index.urlState.evidence,publishedPages:index.publishedUrlState.pages,publishedEvidence:index.publishedUrlState.evidence,originAdjacency:index.urlState.pages.get('https://example.com')?.neighbours,aliasOwners:index.urlAliasOwners,aliasFacets:index.urlAliasFacets,publishedTargets:index.urlPublishedTargets}))if(value&&typeof value==='object')weak.push({name,ref:new WeakRef(value)});memory.live=await snapshot('gc-live-graph');},
    };
    const result=await largeUrlReplayScenario(app,c);
    const finalBefore=performance.timeOrigin+performance.now(),finalNode=hooks.performance.timeOrigin+hooks.performance.now(),finalAfter=performance.timeOrigin+performance.now();memory.clock.finalReadSpanMs=finalAfter-finalBefore;memory.clock.driftMs=(finalBefore+finalAfter)/2-finalNode-clockOffset;check(memory.clock.finalReadSpanMs<5&&Math.abs(memory.clock.driftMs)<5,'Native clock alignment remains stable across replay');
    // The fixture has already destroyed/purged every owned index/cache in finally. Its cleanup
    // closure retains the closed-index array, so drop that explicit test root before collecting.
    delete c.cleanup;delete c.memory;c.index=null;
    memory.disposed=await snapshot('gc-after-disposal');await task();await command('HeapProfiler.collectGarbage');await task();
    memory.collected=weak.map(/** Observe once after collection; deref itself keeps a survivor alive for this job. */({name,ref})=>({name,collected:ref.deref()===undefined}));
    check(memory.collected.every(/** A retained owned index/container is a failed unload check. */entry=>entry.collected),'Owned isolated index/containers must be collected');
    record(observer.takeRecords());check(dropped===0,'GC observation overflow');
    const interval=c.replayWindow;check(interval&&interval.endEpoch>=interval.startEpoch,'Exact replay interval');
    const replayGc=gc.filter(/** Exclude forced pre/post collection and setup; report renderer-wide GC without exclusive attribution. */entry=>entry.startEpoch>=interval.startEpoch&&entry.startEpoch<=interval.endEpoch).map(/** Align native GC intervals with synchronous flush/heartbeat timestamps. */({startEpoch,...entry})=>({...entry,atMs:startEpoch-interval.startEpoch}));
    memory.retainedDeltaBytes=memory.live.heap.usedSize-memory.before.heap.usedSize;
    memory.afterDisposalDeltaBytes=memory.disposed.heap.usedSize-memory.before.heap.usedSize;
    return{...result,memory,replayGc,replayWindow:interval,limitations:'Forced-GC retained renderer JS delta at fixed boundaries, current process metrics in KB (not peak). Single isolated replay, no retained early map. Native GC intervals are renderer-wide, not exclusive compiler CPU. Diagnostic instrumentation/collection changes conditions; do not replace prior elapsed timings or claim paint/mobile/long-session acceptance.'};
  }finally{
    observer?.disconnect();delete c.memory;delete c.cleanup;
    if(owned&&debug.isAttached())debug.detach();
  }
}

await runControlledProbe('large-url-memory',scenario,`const largeUrlReplayScenario=${largeUrlReplayScenario.toString()};`,['src/core/graph/evidence.ts','src/index/IndexedDbCache.ts',...(process.env.KPLEX_PROBE_BASELINE_REF?[]:['src/index/UrlAdjacencyMap.ts'])],{maximumMs:900000});
