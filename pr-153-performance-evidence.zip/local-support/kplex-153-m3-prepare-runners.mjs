/** Derive fresh counterbalanced aggregate A/B5 native conditions from accepted serialized drivers. */
import assert from 'node:assert/strict';
import {readFileSync,writeFileSync} from 'node:fs';
import {join} from 'node:path';
import {tmpdir} from 'node:os';
import {createHash} from 'node:crypto';
const temp=tmpdir(),root=process.cwd(),baseline=readFileSync(join(temp,'kplex-153-m-baseline-artifact-location.txt'),'utf8').trim();
const accepted=JSON.parse(readFileSync(join(root,'docs/validation/indexing-hydration-2026-10-13/host.json'),'utf8'));
for(const name of ['main.js','manifest.json','styles.css'])assert.equal(createHash('sha256').update(readFileSync(join(baseline,'dist',name))).digest('hex'),accepted.artifacts.sourceHashes[name]);
for(const mode of ['retained','unforced']){
  let source=readFileSync(join(temp,`kplex-153-b5-runtime-${mode}-pairs.mjs`),'utf8');
  source=source.replace('kplex-153-b5-baseline-artifact-location.txt','kplex-153-m-baseline-artifact-location.txt').replace("KPLEX_PROBE_BASELINE_REF='3ef54e2'","KPLEX_PROBE_BASELINE_REF='a162044'");
  source=source.replace('docs/validation/indexing-url-search-publication-2026-10-14/host-verification.json','docs/validation/indexing-hydration-2026-10-13/host.json');
  source=source.replace("join(temp,'kplex-153-b5-host/report.json')","join(root,'docs/validation/indexing-url-adjacency-storage-2026-10-14/host-verification.json')");
  source=source.replaceAll(`kplex-153-b5-runtime-${mode}`,`kplex-153-m3-${mode}`);
  if(mode==='retained')source=source.replace('pair<=3','pair<=5');
  writeFileSync(join(temp,`kplex-153-m3-${mode}-pairs.mjs`),source);
}
let direct=readFileSync(join(temp,'kplex-153-m2-default-compat.mjs'),'utf8');
direct=direct.replace("for(let pair=1;pair<=1;pair++)for(const version of ['candidate'])","for(let pair=1;pair<=3;pair++)for(const version of (pair%2?['baseline','candidate']:['candidate','baseline']))");
direct=direct.replaceAll('kplex-153-m2-default-compat','kplex-153-m3-replay');
direct=direct.replace("join(temp,'kplex-153-e3-host/report.json')","join(root,'docs/validation/indexing-url-adjacency-storage-2026-10-14/host-verification.json')");
writeFileSync(join(temp,'kplex-153-m3-replay-pairs.mjs'),direct);
console.log(JSON.stringify({baselineAArtifacts:'verified',retainedPairs:5,unforcedPairs:3,dualLifetimeReplayPairs:3,candidate:'cacefe5 unchanged'}));
