/** Reuse accepted serial staging/window/configuration ownership for one B4 native storage baseline. */
import assert from 'node:assert/strict';
import {readFileSync,writeFileSync} from 'node:fs';
import {join} from 'node:path';
import {tmpdir} from 'node:os';
const temp=tmpdir();let source=readFileSync(join(temp,'kplex-153-b4-retained-pairs.mjs'),'utf8');
source=source.replace("for(let pair=1;pair<=3;pair++)for(const version of ['baseline','candidate'])","for(let pair=1;pair<=1;pair++)for(const version of ['candidate'])");
source=source.replace('kplex-153-b4-retained-pair-${pair}-${version}','kplex-153-b5-storage-baseline');
source=source.replace("join(root,'scripts/testing/obsidian/largeUrlMemory.mjs')","join(root,'scripts/testing/obsidian/largeUrlStorage.mjs')");
source=source.replaceAll('large-url-memory.json','large-url-storage.json');
const start=source.indexOf('const first=r.result.rows[0],timing='),end=source.indexOf('\n}}finally',start);assert(start>=0&&end>start);
source=source.slice(0,start)+"writeFileSync(join(temp,'kplex-153-b5-storage-summary.json'),JSON.stringify({storage:r.result.storage,heapRows:r.result.heapRows},null,2)+'\\n');console.log(JSON.stringify({label,status:r.status,storage:r.result.storage,heapRows:r.result.heapRows.length}));"+source.slice(end);
writeFileSync(join(temp,'kplex-153-b5-storage-runner.mjs'),source);
