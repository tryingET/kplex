/** Validate storage-baseline receipts and report links while retaining every component sample. */
import assert from 'node:assert/strict';
import {readFileSync,writeFileSync,readdirSync,existsSync} from 'node:fs';
import {dirname,resolve,join} from 'node:path';
const raw='docs/validation/indexing-url-storage-baseline-2026-10-14',report=JSON.parse(readFileSync(join(raw,'native-storage.json'),'utf8')),stage=JSON.parse(readFileSync(join(raw,'stage-report.json'),'utf8')),guard=JSON.parse(readFileSync(join(raw,'stage-configuration-guard.json'),'utf8'));
assert.equal(stage.status,'passed');assert(guard.enabledBytesRestored&&guard.settingsUnchanged);assert.equal(report.status,'passed');assert.equal(report.cleanup,'passed');assert.equal(report.result.heapRows.length,24);
const full=JSON.parse(readFileSync('docs/validation/indexing-url-search-publication-2026-10-14/host-verification.json','utf8'));assert.deepEqual(report.artifacts,full.artifacts.sourceHashes);
const ledgerPath=join(raw,'environment-and-sources.json'),ledger=JSON.parse(readFileSync(ledgerPath,'utf8'));delete ledger.baselineFullVerification;ledger.verification={runtimeSourceUnchanged:true,fullVerification:'B4 exact-artifact receipt reused',nativeReplay:'passed',componentSamples:24,componentRootArraysCollected:24,outerCleanup:'passed',nodeSyntax:'passed',newFullSuiteRun:false};writeFileSync(ledgerPath,JSON.stringify(ledger,null,2)+'\n');
for(const name of readdirSync(raw))if(name.endsWith('.json'))JSON.parse(readFileSync(join(raw,name),'utf8'));
let links=0;for(const match of readFileSync(raw+'.md','utf8').matchAll(/\]\(([^)]+)\)/g)){if(/^(https?:|#)/.test(match[1]))continue;assert(existsSync(resolve(dirname(raw+'.md'),decodeURIComponent(match[1].split('#')[0]))),match[1]);links++;}
console.log(JSON.stringify({checks:'passed',json:6,links,componentSamples:24,retainedNegativeSamples:report.result.heapRows.filter(/** Preserve drift observations rather than dropping inconvenient samples. */row=>row.retainedBytes<0).length}));
