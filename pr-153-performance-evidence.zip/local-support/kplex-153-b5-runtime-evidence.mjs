/** Prepare exact B5 work/lifecycle receipts and reuse accepted native interval/audit ownership. */
import assert from 'node:assert/strict';
import {readFileSync,writeFileSync,mkdirSync,copyFileSync} from 'node:fs';
import {join} from 'node:path';
import {tmpdir} from 'node:os';
const temp=tmpdir(),raw='docs/validation/indexing-url-adjacency-storage-2026-10-14';mkdirSync(raw,{recursive:true});
/** Normalize only transport encoding, line endings and trailing log whitespace, retaining failure content. */
const readLog=name=>{const b=readFileSync(join(temp,name));return b.toString(b[0]===255&&b[1]===254?'utf16le':'utf8').replace(/^\uFEFF/,'').replaceAll('\r\n','\n').replace(/[ \t]+$/gm,'');};
copyFileSync(join(temp,'kplex-153-b5-work-comparison.json'),join(raw,'work-comparison.json'));
for(const[source,target]of [['kplex-153-b5-focused.log','focused-final.tap'],['kplex-153-b5-baseline-lifetime-tests.log','baseline-lifetime.tap'],['kplex-153-b5-build.log','environment-build-denied.log'],['kplex-153-b5-build-native.log','authorized-build.log']])writeFileSync(join(raw,target),readLog(source));
let analysis=readFileSync(join(temp,'kplex-153-b4-analysis.mjs'),'utf8').replace("raw='docs/validation/indexing-url-search-publication-2026-10-14'",`raw='${raw}'`).replaceAll('kplex-153-b4-${mode}','kplex-153-b5-runtime-${mode}');
assert(analysis.includes('kplex-153-b5-runtime-${mode}'));writeFileSync(join(temp,'kplex-153-b5-runtime-analysis.mjs'),analysis);
let audit=readFileSync(join(temp,'kplex-153-b4-audit.mjs'),'utf8').replace("raw='docs/validation/indexing-url-search-publication-2026-10-14'",`raw='${raw}'`);
audit=audit.replace("'docs/validation/indexing-private-compiler-append-2026-10-14/environment-and-sources.json'","'docs/validation/indexing-url-search-publication-2026-10-14/environment-and-sources.json'");
audit=audit.replace("file!=='src/index/GraphIndex.ts'","file!=='src/index/UrlAdjacencyMap.ts'");
audit=audit.replace('kplex-153-b4-host-complete/report.json','kplex-153-b5-host/report.json');
audit=audit.replace("baseline:'99f12f3',candidateRuntime:'B4 uncommitted exact source/artifact hashes'","baseline:'3ef54e2',candidateRuntime:'B5 exact source/artifact hashes'");
audit=audit.replace("['kplex-153-b4-retained-pairs.mjs','kplex-153-b4-unforced-pairs.mjs','kplex-153-b4-analysis.mjs','kplex-153-b4-prepare-evidence.mjs','kplex-153-b2-restage.mjs']","['kplex-153-b5-runtime-retained-pairs.mjs','kplex-153-b5-runtime-unforced-pairs.mjs','kplex-153-b5-runtime-analysis.mjs','kplex-153-b5-runtime-evidence.mjs','kplex-153-b2-restage.mjs']");
audit=audit.replace("baselineFullVerification:'indexing-private-compiler-append-2026-10-14/host-verification.json'","baselineFullVerification:'indexing-url-search-publication-2026-10-14/host-verification.json'");
writeFileSync(join(temp,'kplex-153-b5-runtime-audit.mjs'),audit);
console.log(JSON.stringify({workAndFocusedReceipts:'saved',nativeAnalysisAndAudit:'prepared',raw}));
