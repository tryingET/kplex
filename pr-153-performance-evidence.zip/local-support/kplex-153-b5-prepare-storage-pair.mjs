/** Preserve accepted native window/configuration ownership for a matched B4/B5 container sample pair. */
import assert from 'node:assert/strict';
import {readFileSync,writeFileSync} from 'node:fs';
import {join} from 'node:path';
import {tmpdir} from 'node:os';
const temp=tmpdir();let source=readFileSync(join(temp,'kplex-153-b5-storage-runner.mjs'),'utf8');
assert(source.includes("for(const version of ['candidate'])"));
source=source.replace("for(const version of ['candidate'])","for(const version of ['baseline','candidate'])");
source=source.replace('kplex-153-b5-storage-baseline','kplex-153-b5-runtime-storage-${version}');
source=source.replace('kplex-153-b4-baseline-artifact-location.txt','kplex-153-b5-baseline-artifact-location.txt');
source=source.replace("KPLEX_PROBE_BASELINE_REF='99f12f3'","KPLEX_PROBE_BASELINE_REF='3ef54e2'");
source=source.replace('docs/validation/indexing-private-compiler-append-2026-10-14/host-verification.json','docs/validation/indexing-url-search-publication-2026-10-14/host-verification.json');
source=source.replace('kplex-153-b4-host-complete/report.json','kplex-153-b5-host/report.json');
source=source.replace("join(temp,'kplex-153-b5-storage-summary.json')","join(temp,`${label}-summary.json`)");
writeFileSync(join(temp,'kplex-153-b5-runtime-storage-pair.mjs'),source);
