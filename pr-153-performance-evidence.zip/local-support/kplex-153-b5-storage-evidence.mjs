/** Preserve the native storage gate and prepare an unchanged-runtime physical/configuration audit. */
import assert from 'node:assert/strict';
import {readFileSync,writeFileSync,copyFileSync,mkdirSync} from 'node:fs';
import {join} from 'node:path';
import {tmpdir} from 'node:os';
import {createHash} from 'node:crypto';
import {runInNewContext} from 'node:vm';
const temp=tmpdir(),raw='docs/validation/indexing-url-storage-baseline-2026-10-14';mkdirSync(raw,{recursive:true});
const report=JSON.parse(readFileSync(join(temp,'kplex-153-b5-storage-baseline/large-url-storage.json'),'utf8'));
assert.equal(report.status,'passed');assert.equal(report.cleanup,'passed');assert.equal(report.result.heapRows.length,24);assert(report.result.heapRows.every(/** Each component lifetime releases its exact owned root array. */row=>row.rootsCollected));
const row=report.result.rows[0];assert.deepEqual(row.operations,{reads:0,parses:0});assert.equal(row.workingDigest,'31a78202bb997736c2ea056a0d3e1865070e0454f0c04f023f6f9688f8042d50');assert.equal(row.displayDigest,row.workingDigest);
const source=readFileSync('scripts/testing/obsidian/largeUrlStorage.mjs','utf8'),scenario=runInNewContext(source.slice(source.indexOf('async function scenario'),source.lastIndexOf('\nawait runControlledProbe'))+';scenario.toString()');
assert.equal(report.driver.scenario,createHash('sha256').update(scenario).digest('hex'));
copyFileSync(join(temp,'kplex-153-b5-storage-baseline/large-url-storage.json'),join(raw,'native-storage.json'));
for(const file of ['report.json','configuration-guard.json'])copyFileSync(join(temp,'kplex-153-b5-storage-baseline-stage',file),join(raw,'stage-'+file));
const medians=[];for(const entries of [0,1,2,8]){const kinds={};for(const kind of ['native','wrapper']){const values=report.result.heapRows.filter(/** Keep all three actual samples, including a negative drift observation. */row=>row.entries===entries&&row.kind===kind).map(/** Component bytes already subtract the immediately preceding collected baseline. */row=>row.retainedBytes);assert.equal(values.length,3);kinds[kind]={values,median:[...values].sort(/** Numeric order must not become lexicographic. */(a,b)=>a-b)[1]};}medians.push({entries,...kinds,differenceBytes:kinds.wrapper.median-kinds.native.median});}
writeFileSync(join(raw,'analysis.json'),JSON.stringify({storage:report.result.storage,medians,limits:'Composite installed-wrapper/native difference includes all wrapper metadata and separate storage; not a predicted superclass-backing saving. Negative control sample retained; unrelated renderer heap can drift.'},null,2)+'\n');
let audit=readFileSync(join(temp,'kplex-153-b4-audit.mjs'),'utf8').replace("raw='docs/validation/indexing-url-search-publication-2026-10-14'",`raw='${raw}'`);
audit=audit.replace("'scripts/testing/obsidian/processTools.mjs'])sources", "'scripts/testing/obsidian/processTools.mjs','scripts/testing/obsidian/largeUrlStorage.mjs'])sources");
audit=audit.replace("baseline:'99f12f3',candidateRuntime:'B4 uncommitted exact source/artifact hashes'","baseline:'ba83041',candidateRuntime:'ba83041 unchanged'").replace('runtimeUnchanged:false','runtimeUnchanged:true');
audit=audit.replace("fullVerification:'host-verification.json'","fullVerificationReused:'../indexing-url-search-publication-2026-10-14/host-verification.json'");
audit=audit.replace("['kplex-153-b4-retained-pairs.mjs','kplex-153-b4-unforced-pairs.mjs','kplex-153-b4-analysis.mjs','kplex-153-b4-prepare-evidence.mjs','kplex-153-b2-restage.mjs']","['kplex-153-b5-storage-runner.mjs','kplex-153-b5-prepare-storage-runner.mjs','kplex-153-b5-storage-evidence.mjs','kplex-153-b2-restage.mjs']");
audit=audit.replace('Matched retained/unforced diagnostic conditions separate; Final full-suite/exact native verification separate;', 'Representation counts and native component-control heap; unchanged-runtime full verification reused, no new suite run;');
writeFileSync(join(temp,'kplex-153-b5-storage-audit.mjs'),audit);
console.log(JSON.stringify({storage:report.result.storage,medians}));
