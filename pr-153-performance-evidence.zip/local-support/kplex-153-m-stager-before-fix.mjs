﻿import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
import {join} from 'node:path';
import {pathToFileURL} from 'node:url';
import {createHash} from 'node:crypto';
const root=process.cwd(),projectRoot=process.env.KPLEX_STAGE_PROJECT,receiptPath=process.env.KPLEX_STAGE_RECEIPT;
assert(projectRoot&&receiptPath,'Explicit project and full receipt required');
const {runObsidianVerification}=await import(pathToFileURL(join(root,'scripts/testing/obsidian/runner.mjs'))),{spawnNativeSync,obsidianCliExecutable}=await import(pathToFileURL(join(root,'scripts/testing/obsidian/processTools.mjs')));
const receipt=JSON.parse(readFileSync(receiptPath,'utf8'));assert.equal(receipt.status,'passed');
const originalData=readFileSync(join(process.env.KPLEX_TEST_CONFIG_DIR,'plugins/k-plex/data.json')),originalEnabled=readFileSync(join(process.env.KPLEX_TEST_CONFIG_DIR,'community-plugins.json'));
const command=(vault,name,...args)=>{const r=spawnNativeSync(obsidianCliExecutable(),[`vault=${vault}`,name,...args],{cwd:root,encoding:'utf8',timeout:30000,killSignal:'SIGKILL',maxBuffer:4*1024*1024});assert.equal(r.status,0,r.error?.message||r.stderr);assert(!/^Error:/m.test(r.stdout),r.stdout);return r.stdout;};
const report=await runObsidianVerification({projectRoot,vaultName:process.env.KPLEX_TEST_VAULT_NAME,vaultPath:process.env.KPLEX_TEST_VAULT_PATH,configDir:process.env.KPLEX_TEST_CONFIG_DIR,reportDir:process.env.KPLEX_HOST_REPORT_DIR,
source:{reusesFullVerification:receiptPath,reason:'Exact three-artifact hashes reuse full acceptance; only staging/render rerun'},
runVerify:()=>{for(const file of ['main.js','manifest.json','styles.css'])assert.equal(createHash('sha256').update(readFileSync(join(projectRoot,'dist',file))).digest('hex'),receipt.artifacts.sourceHashes[file]);},
runCli:(vault,name,...args)=>{if(name==='plugin:enable')command(vault,'eval','code=(()=>{const r=require("@electron/remote"),w=r.getCurrentWindow();r.app.focus({steal:true});w.restore();w.show();w.focus();return true})()');return command(vault,name,...args);}});
assert.equal(report.status,'passed',report.error);assert(readFileSync(join(process.env.KPLEX_TEST_CONFIG_DIR,'plugins/k-plex/data.json')).equals(originalData),'Settings bytes');assert(readFileSync(join(process.env.KPLEX_TEST_CONFIG_DIR,'community-plugins.json')).equals(originalEnabled),'Enablement bytes');console.log(JSON.stringify({status:report.status,artifacts:report.artifacts.sourceHashes}));
