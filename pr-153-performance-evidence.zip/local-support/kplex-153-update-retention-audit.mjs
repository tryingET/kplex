/** Independently audit real small-vault inventory, primary cache retirement and native resource state after the retention exercise. */
import {runControlledProbe} from 'file:///C:/Users/viczi/GitHub/kplex/scripts/testing/obsidian/controlledProbe.mjs';

/** Read current native facts and primary URL rows without altering settings, caches or source authority. */
async function scenario(app,c){
  const p=app.plugins.plugins['k-plex'],path='__kplex-153-url-probe.md',win=require('@electron/remote').getCurrentWindow();
  /** Fail closed if cleanup is incomplete; retain the existing one-minute settle bound. */
  const check=(value,message)=>{if(!value)throw Error(message);};
  const end=performance.now()+60000;
  while(!p.getIndexStatus().upToDate||p.index.urlDiscoveryRunning||p.index.urlPendingPublications||p.index.urlOwnerTasks.size||p.index.urlCacheWrites.size||p.index.sourceAcquisition.inventory){check(!c.closed&&performance.now()<end,'Post-retention native settle');await new Promise(/** This wait observes actual completion without changing pacing. */resolve=>window.setTimeout(resolve,50));}
  check(app.vault.getName()==='kplex-test-small','Exact authorized small vault');check(app.vault.getMarkdownFiles().length===88&&app.vault.getFiles().length===106,'Original small-vault inventory');
  check(!app.vault.getFileByPath(path)&&!app.vault.getFolderByPath('__kplex-153-url-probe-owners')&&!p.index.urlOwners.has(path),'Owned native fixture and primary owner removed');
  let rows=0,ownedRows=0;
  const complete=await p.index.indexedDb.readUrlOwners(/** Inspect only path equality/counts; no original record payload is saved. */async records=>{for(const record of records){rows++;if(record.path===path)ownedRows++;}},/** The read cannot continue after audit cancellation. */()=>!c.closed);
  check(complete&&ownedRows===0,'Primary persisted URL row retired');check(!win.webContents.debugger.isAttached(),'No retained debugger');check(win.webContents.getBackgroundThrottling(),'Native background policy preserved');
  return{vault:app.vault.getName(),markdown:app.vault.getMarkdownFiles().length,files:app.vault.getFiles().length,primaryUrlRows:rows,ownedRows,fixtureRemoved:true,primaryUrlOwners:p.index.urlOwners.size,primaryUrlComplete:p.index.urlDiscoveryComplete,sourceInventory:Boolean(p.index.sourceAcquisition.inventory),debuggerAttached:false,throttling:true,window:{bounds:win.getBounds(),maximized:win.isMaximized(),minimized:win.isMinimized()},limits:'Read-only post-exercise state and persisted-row audit. Shared fixture owns captured geometry restoration; no serialized before/after workspace comparison or process-peak claim.'};
}

await runControlledProbe('url-update-retention-audit',scenario,'',['src/index/UrlAdjacencyMap.ts']);
