/** Preserve matched installed-wrapper component measurements without discarding drift or predicting graph heap from container bytes. */
import assert from 'node:assert/strict';
import {readFileSync,writeFileSync,copyFileSync} from 'node:fs';
import {join} from 'node:path';
import {tmpdir} from 'node:os';
import {createHash} from 'node:crypto';
import {runInNewContext} from 'node:vm';
import {execFileSync} from 'node:child_process';
const temp=tmpdir(),raw='docs/validation/indexing-url-adjacency-storage-2026-10-14';
/** Hash actual source/function bytes independently of the driver's report. */
const hash=value=>createHash('sha256').update(value).digest('hex');
const source=readFileSync('scripts/testing/obsidian/largeUrlStorage.mjs','utf8'),scenario=runInNewContext(source.slice(source.indexOf('async function scenario'),source.lastIndexOf('\nawait runControlledProbe'))+';scenario.toString()'),replaySource=readFileSync('scripts/testing/obsidian/largeUrlReplay.mjs','utf8'),replay=runInNewContext(replaySource.slice(replaySource.indexOf('export async function largeUrlReplayScenario')+7,replaySource.lastIndexOf('\nif(process.argv'))+';largeUrlReplayScenario.toString()');
const cases=[];
for(const version of ['baseline','candidate']){
  const folder=`kplex-153-b5-runtime-storage-${version}`,report=JSON.parse(readFileSync(join(temp,folder,'large-url-storage.json'),'utf8')),result=report.result,row=result.rows[0];
  assert.equal(report.status,'passed');assert.equal(report.cleanup,'passed');assert.equal(report.driver.scenario,hash(scenario));assert.equal(report.driver.definitions,hash(`const largeUrlReplayScenario=${replay};`));
  assert.equal(row.workingDigest,'31a78202bb997736c2ea056a0d3e1865070e0454f0c04f023f6f9688f8042d50');assert.equal(row.displayDigest,row.workingDigest);assert.equal(row.seedDigest,'f4efd617186c7464198e8a8ca7073fed49d3e2a23d73f80af76f21e87014f5af');assert.equal(result.physicalDigest,'c88c1776685b60c1456806457ac97679653f30326c6ef572ba5b13e747f607e0');assert.deepEqual(row.operations,{reads:0,parses:0});
  assert.equal(result.heapRows.length,24);assert(result.heapRows.every(/** All component roots, including noisy byte samples, complete their owned lifetime. */item=>item.rootsCollected));
  const sourceHash=version==='baseline'?hash(execFileSync('git',['show','3ef54e2:src/index/UrlAdjacencyMap.ts'],{encoding:'utf8'})):hash(readFileSync('src/index/UrlAdjacencyMap.ts'));
  assert.equal(report.source['src/index/UrlAdjacencyMap.ts'],sourceHash);assert.equal(result.storage.urlPages,8040);
  if(version==='baseline'){assert.equal(result.storage.separateDeltaMaps,result.storage.uniqueWrappers);assert.equal(result.storage.nativeBackingEntries,0);}else{assert.equal(result.storage.separateDeltaMaps,0);assert(result.storage.nativeBackingEntries>0);}
  const medians=[];for(const entries of [0,1,2,8]){const kinds={};for(const kind of ['native','wrapper']){const values=result.heapRows.filter(/** Preserve the prespecified density and every round. */item=>item.entries===entries&&item.kind===kind).map(/** Collected live-minus-empty JS delta is not allocation or process peak. */item=>item.retainedBytes);assert.equal(values.length,3);kinds[kind]={values,median:[...values].sort(/** Numeric byte order. */(a,b)=>a-b)[1]};}medians.push({entries,...kinds});}
  copyFileSync(join(temp,folder,'large-url-storage.json'),join(raw,`storage-${version}.json`));
  for(const file of ['report.json','configuration-guard.json']){const stage=JSON.parse(readFileSync(join(temp,folder+'-stage',file),'utf8'));if(file==='report.json')assert.equal(stage.status,'passed');else assert(stage.enabledBytesRestored&&stage.settingsUnchanged);copyFileSync(join(temp,folder+'-stage',file),join(raw,`storage-${version}-stage-${file}`));}
  cases.push({version,sourceHash,storage:result.storage,medians});
}
writeFileSync(join(raw,'storage-analysis.json'),JSON.stringify({cases,limits:'Identical prespecified numeric container samples; keep every byte delta, including negative background drift. Separate component results from complete graph heap, timing and process peak.'},null,2)+'\n');
console.log(JSON.stringify(cases));
