/** Reuse accepted serial native pair ownership with exact B4 versus B5 storage artifacts. */
import assert from 'node:assert/strict';
import {readFileSync,writeFileSync} from 'node:fs';
import {join} from 'node:path';
import {tmpdir} from 'node:os';
const temp=tmpdir();
for(const mode of ['retained','unforced']){
  let source=readFileSync(join(temp,`kplex-153-b4-${mode}-pairs.mjs`),'utf8');
  assert(source.includes("KPLEX_PROBE_BASELINE_REF='99f12f3'"));
  source=source.replace('kplex-153-b4-baseline-artifact-location.txt','kplex-153-b5-baseline-artifact-location.txt');
  source=source.replace("KPLEX_PROBE_BASELINE_REF='99f12f3'","KPLEX_PROBE_BASELINE_REF='3ef54e2'");
  source=source.replace('docs/validation/indexing-private-compiler-append-2026-10-14/host-verification.json','docs/validation/indexing-url-search-publication-2026-10-14/host-verification.json');
  source=source.replace('kplex-153-b4-host-complete/report.json','kplex-153-b5-host/report.json');
  source=source.replaceAll(`kplex-153-b4-${mode}`,`kplex-153-b5-runtime-${mode}`);
  source=source.replace("for(let pair=1;pair<=3;pair++)for(const version of ['baseline','candidate'])","for(let pair=1;pair<=3;pair++)for(const version of (pair%2?['baseline','candidate']:['candidate','baseline']))");
  writeFileSync(join(temp,`kplex-153-b5-runtime-${mode}-pairs.mjs`),source);
}
