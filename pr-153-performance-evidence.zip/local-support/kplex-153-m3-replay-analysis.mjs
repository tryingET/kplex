/** Validate aggregate counted versus low-instrumentation replay lifetimes without mixing their timing or display cadence. */
import assert from 'node:assert/strict';
import {readFileSync,writeFileSync,copyFileSync} from 'node:fs';
import {join} from 'node:path';
import {tmpdir} from 'node:os';
import {createHash} from 'node:crypto';
import {runInNewContext} from 'node:vm';
const temp=tmpdir(),raw='docs/validation/indexing-native-url-aggregate-2026-10-14';
/** Function identity and empty definitions are checked against actual current driver bytes. */
const hash=value=>createHash('sha256').update(value).digest('hex');
const source=readFileSync('scripts/testing/obsidian/largeUrlReplay.mjs','utf8'),scenario=runInNewContext(source.slice(source.indexOf('export async function largeUrlReplayScenario')+7,source.lastIndexOf('\nif(process.argv'))+';largeUrlReplayScenario.toString()'),rows=[];
for(let pair=1;pair<=3;pair++)for(const version of ['baseline','candidate']){
  const folder=`kplex-153-m3-replay-pair-${pair}-${version}`,report=JSON.parse(readFileSync(join(temp,folder,'large-url-replay.json'),'utf8')),result=report.result;
  assert.equal(report.status,'passed');assert.equal(report.cleanup,'passed');assert.equal(report.driver.scenario,hash(scenario));assert.equal(report.driver.definitions,hash(''));
  assert.equal(result.physicalDigest,'c88c1776685b60c1456806457ac97679653f30326c6ef572ba5b13e747f607e0');assert.equal(result.rows.length,2);assert.equal(result.rows[0].observe,true);assert.equal(result.rows[1].observe,false);
  for(const row of result.rows){assert.equal(row.seedDigest,'f4efd617186c7464198e8a8ca7073fed49d3e2a23d73f80af76f21e87014f5af');assert.equal(row.workingDigest,'31a78202bb997736c2ea056a0d3e1865070e0454f0c04f023f6f9688f8042d50');assert.equal(row.displayDigest,row.workingDigest);assert.deepEqual(row.operations,{reads:0,parses:0});assert.equal(row.pages,16069);assert.equal(row.declarations,16127);assert.equal(row.originDegree,8000);}
  const counted=result.rows[0],timing=result.rows[1];assert.equal(counted.workingEntries,version==='baseline'?31996000:0);
  copyFileSync(join(temp,folder,'large-url-replay.json'),join(raw,`replay-pair-${pair}-${version}.json`));
  for(const file of ['report.json','configuration-guard.json']){const stage=JSON.parse(readFileSync(join(temp,folder+'-stage',file),'utf8'));if(file==='report.json')assert.equal(stage.status,'passed');else assert(stage.enabledBytesRestored&&stage.settingsUnchanged);copyFileSync(join(temp,folder+'-stage',file),join(raw,`replay-pair-${pair}-${version}-stage-${file}`));}
  rows.push({pair,version,elapsedMs:timing.elapsedMs,workingEntries:counted.workingEntries,countedDisplayEntries:counted.displayEntries,countedFlushes:counted.flushes,timingFlushes:timing.flushes,countedLargestGapMs:counted.heartbeat.largestGapMs,seedMs:[counted.seedMs,timing.seedMs]});
}
writeFileSync(join(raw,'replay-analysis.json'),JSON.stringify({rows,limits:'Only second unwrapped lifetime contributes elapsed comparisons; counted first lifetime establishes work and retained-map equivalence. Display counts depend on natural elapsed cadence and are not fixed-work comparisons. Namespace seeding is outside API timing.'},null,2)+'\n');
console.log(JSON.stringify(rows));
