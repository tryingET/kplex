/** Validate retention report links/receipts and unchanged production/artifact provenance before delivery. */
import assert from 'node:assert/strict';
import {readFileSync,readdirSync,existsSync} from 'node:fs';
import {join,dirname,resolve} from 'node:path';
import {execFileSync} from 'node:child_process';
const raw='docs/validation/indexing-url-update-retention-2026-10-14';let json=0,links=0;
for(const name of readdirSync(raw))if(name.endsWith('.json')){JSON.parse(readFileSync(join(raw,name),'utf8'));json++;}
for(const match of readFileSync(raw+'.md','utf8').matchAll(/\]\(([^)]+)\)/g)){if(/^(https?:|#)/.test(match[1]))continue;assert(existsSync(resolve(dirname(raw+'.md'),decodeURIComponent(match[1].split('#')[0]))),match[1]);links++;}
assert.equal(execFileSync('git',['diff','HEAD','--','src'],{encoding:'utf8'}),'');
const final=JSON.parse(readFileSync(join(raw,'final-64.json'),'utf8')),audit=JSON.parse(readFileSync(join(raw,'cleanup-audit.json'),'utf8'));assert.equal(final.result.liveDisposedPublishedMaps,0);assert.equal(final.result.indexCollected,true);assert.equal(audit.result.ownedRows,0);
console.log(JSON.stringify({json,links,cycles:64,reads:final.result.operations.reads,parses:final.result.operations.parses,indexCollected:true,observedMaps:65,liveMapsAfterDisposal:0,ownedPrimaryCacheRows:0,runtimeUnchanged:true,checks:'passed'}));
