/** Preserve B4 exact work, preliminary verification and regression receipts without promoting them to final acceptance. */
import assert from 'node:assert/strict';
import {readFileSync,writeFileSync,mkdirSync,copyFileSync} from 'node:fs';
import {join} from 'node:path';
import {tmpdir} from 'node:os';
const temp=tmpdir(),raw='docs/validation/indexing-url-search-publication-2026-10-14';mkdirSync(raw,{recursive:true});
/** PowerShell 5 redirected native output uses UTF-16LE; decode before preserving normalized receipts. */
const readLog=name=>{const b=readFileSync(join(temp,name));return b.toString(b[0]===255&&b[1]===254?'utf16le':'utf8').replace(/^\uFEFF/,'');};
const baseline=JSON.parse(readLog('kplex-153-b4-work-baseline.log')),candidate=JSON.parse(readLog('kplex-153-b4-work-candidate-complete.log'));
assert.equal(baseline.rows.length,5);assert.equal(candidate.rows.length,5);
for(let n=0;n<5;n++){const b=baseline.rows[n],c=candidate.rows[n];assert.equal(c.owners,b.owners);assert.equal(c.digest,b.digest);assert.deepEqual(c.operations,{reads:0,parses:0});assert.equal(c.coveredGets,0);}
writeFileSync(join(raw,'work-comparison.json'),JSON.stringify({baseline,candidate},null,2)+'\n');
for(const [source,target] of [['kplex-153-b4-focused-complete.log','focused-final.tap'],['kplex-153-b4-retention-regression-before-fix.log','failed-initial-retention.tap'],['kplex-153-b4-bounded-regression-before-fix.log','failed-intermediate-bounded-work.tap']])writeFileSync(join(raw,target),readLog(source));
for(const [source,target] of [['kplex-153-b4-host/report.json','preliminary-skip-host.json'],['kplex-153-b4-host-final/report.json','preliminary-remove-host.json'],['kplex-153-b4-initial-GraphIndex.ts','preliminary-skip-GraphIndex.txt'],['kplex-153-b4-remove-GraphIndex.ts','preliminary-remove-GraphIndex.txt']])copyFileSync(join(temp,source),join(raw,target));
console.log(JSON.stringify({workCells:5,largest:candidate.rows.at(-1),raw}));
let analysis=readFileSync(join(temp,'kplex-153-m2-analysis.mjs'),'utf8');
analysis=analysis.replace("raw='docs/validation/indexing-native-url-memory-2026-10-14'",`raw='${raw}'`);
const start=analysis.indexOf('const cases=[];'),end=analysis.indexOf('const summary=[];',start);
assert(start>=0&&end>start);
analysis=analysis.slice(0,start)+"const cases=[];for(const mode of ['retained','unforced'])for(let pair=1;pair<=3;pair++)for(const version of ['baseline','candidate'])cases.push({mode,pair,version,folder:`kplex-153-b4-${mode}-pair-${pair}-${version}`});"+analysis.slice(end);
const excluded=analysis.indexOf("copyFileSync(join(temp,'kplex-153-m2-retained-pair-1-baseline/large-url-memory.json')"),write=analysis.indexOf("writeFileSync(join(raw,'matched-analysis.json')",excluded);
assert(excluded>=0&&write>excluded);
analysis=analysis.slice(0,excluded)+analysis.slice(write);
writeFileSync(join(temp,'kplex-153-b4-analysis.mjs'),analysis);
let audit=readFileSync(join(temp,'kplex-153-m2-audit.mjs'),'utf8');
audit=audit.replace("raw='docs/validation/indexing-native-url-memory-2026-10-14'",`raw='${raw}'`);
audit=audit.replace("if(file.startsWith('src/'))assert.equal(sources[file],value);assert.equal(execFileSync('git',['diff','HEAD','--','src'],{encoding:'utf8'}),'');","if(file.startsWith('src/')&&file!=='src/index/GraphIndex.ts')assert.equal(sources[file],value);");
audit=audit.replace("assert.equal(artifacts[name],old.artifacts[name]);","assert.equal(artifacts[name],JSON.parse(readFileSync(join(temp,'kplex-153-b4-host-complete/report.json'),'utf8')).artifacts.sourceHashes[name]);");
audit=audit.replace("['kplex-153-m2-retained-pairs.mjs','kplex-153-m2-replacement.mjs','kplex-153-m2-unforced-pairs.mjs','kplex-153-m2-default-compat.mjs','kplex-153-m2-analysis.mjs','kplex-153-b2-restage.mjs','kplex-153-m2-node-observer-attempt.mjs']","['kplex-153-b4-retained-pairs.mjs','kplex-153-b4-unforced-pairs.mjs','kplex-153-b4-analysis.mjs','kplex-153-b4-prepare-evidence.mjs','kplex-153-b2-restage.mjs']");
audit=audit.replace("baseline:'a162044',candidateRuntime:'0ad463c'","baseline:'99f12f3',candidateRuntime:'B4 uncommitted exact source/artifact hashes'");
audit=audit.replace('runtimeUnchanged:true','runtimeUnchanged:false');
audit=audit.replace("fullVerificationReused:'indexing-private-compiler-append-2026-10-14/host-verification.json',baselineFullVerification:'indexing-hydration-2026-10-13/host.json'","fullVerification:'host-verification.json',baselineFullVerification:'indexing-private-compiler-append-2026-10-14/host-verification.json'");
audit=audit.replace('no full-suite rerun/unconditional performance/paint/processpeak/mobile/long-session acceptance','Final full-suite/exact native verification separate; no unconditional performance/paint/processpeak/mobile/long-session acceptance');
writeFileSync(join(temp,'kplex-153-b4-audit.mjs'),audit.replaceAll("from'./scripts/testing/", "from'file:///"+process.cwd().replaceAll('\\','/')+"/scripts/testing/"));
