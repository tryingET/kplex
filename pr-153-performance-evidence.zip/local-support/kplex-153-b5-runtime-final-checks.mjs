/** Verify B5 final exact-source/native artifacts and every saved receipt/link before checkpoint delivery. */
import assert from 'node:assert/strict';
import {readFileSync,writeFileSync,readdirSync,existsSync} from 'node:fs';
import {dirname,resolve,join} from 'node:path';
import {createHash} from 'node:crypto';
import {execFileSync} from 'node:child_process';
import {tmpdir} from 'node:os';
const raw='docs/validation/indexing-url-adjacency-storage-2026-10-14',ledgerPath=join(raw,'environment-and-sources.json'),ledger=JSON.parse(readFileSync(ledgerPath,'utf8'));
/** Record exact input bytes; native probes and work oracles independently retain the runtime hashes. */
const hash=value=>createHash('sha256').update(value).digest('hex');
assert.equal(hash(readFileSync('src/index/UrlAdjacencyMap.ts')),'375c260daf99de88004e1f18dac7d9f601ad998e2ee9d8c31af2a846c32800a4');
ledger.baselineStorageSource={ref:'3ef54e2',file:'src/index/UrlAdjacencyMap.ts',sha256:hash(execFileSync('git',['show','3ef54e2:src/index/UrlAdjacencyMap.ts'],{encoding:'utf8'})),artifactReceipt:'../indexing-url-search-publication-2026-10-14/host-verification.json',note:'Historical-compatible memory driver omits this baseline extra-source field; exact accepted B4 artifacts and the matched storage probe independently identify it.'};
ledger.validationInputs={};for(const file of ['package.json','tests/url-adjacency-map.test.mjs','tests/url-adjacency-publication.test.mjs','tests/url-search-publication.test.mjs','scripts/testing/url-adjacency-work.mjs','scripts/testing/obsidian/largeUrlStorage.mjs'])ledger.validationInputs[file]=hash(readFileSync(file));
for(const file of ['kplex-153-b5-runtime-storage-pair.mjs','kplex-153-b5-component-analysis.mjs'])ledger.helperSources[file]=hash(readFileSync(join(tmpdir(),file)));
ledger.verification={fullExitCode:0,architecture:7,core:128,normal:824,ui:63,portableSources:334,browser:495,focused:33,baselineMapTests:9,workCells:5,foregroundCases:6,nativeHeapPairs:6,nativeHeapReplays:12,componentSamples:48,lint:'passed',productionBuild:'passed',nativeSmoke:'passed'};
writeFileSync(ledgerPath,JSON.stringify(ledger,null,2)+'\n');
const full=JSON.parse(readFileSync(join(raw,'host-verification.json'),'utf8'));assert.equal(full.status,'passed');assert.deepEqual(full.artifacts.sourceHashes,ledger.artifacts);
const work=JSON.parse(readFileSync(join(raw,'work-comparison.json'),'utf8'));assert.deepEqual(work.baseline.rows,work.candidate.rows);assert.equal(work.candidate.sources['src/index/UrlAdjacencyMap.ts'],ledger.sources['src/index/UrlAdjacencyMap.ts']);
const storage=JSON.parse(readFileSync(join(raw,'storage-analysis.json'),'utf8'));assert.equal(storage.cases.length,2);assert.equal(storage.cases[1].storage.separateDeltaMaps,0);
let json=0;for(const name of readdirSync(raw))if(name.endsWith('.json')){JSON.parse(readFileSync(join(raw,name),'utf8'));json++;}
let links=0;for(const match of readFileSync(raw+'.md','utf8').matchAll(/\]\(([^)]+)\)/g)){if(/^(https?:|#)/.test(match[1]))continue;assert(existsSync(resolve(dirname(raw+'.md'),decodeURIComponent(match[1].split('#')[0]))),match[1]);links++;}
console.log(JSON.stringify({checks:'passed',json,links,sourceHash:ledger.sources['src/index/UrlAdjacencyMap.ts'],artifacts:ledger.artifacts}));
