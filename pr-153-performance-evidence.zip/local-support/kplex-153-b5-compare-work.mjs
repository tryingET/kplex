/** Compare exact B4/storage-candidate work and ordered semantic oracles without changing the checkout. */
import assert from 'node:assert/strict';
import {readFileSync,writeFileSync} from 'node:fs';
import {join} from 'node:path';
import {tmpdir} from 'node:os';
const temp=tmpdir();
/** Decode PowerShell native redirection before interpreting the declared benchmark JSON. */
const read=name=>{const b=readFileSync(join(temp,name));return JSON.parse(b.toString(b[0]===255&&b[1]===254?'utf16le':'utf8').replace(/^\uFEFF/,''));};
const baseline=read('kplex-153-b5-work-baseline.log'),candidate=read('kplex-153-b5-work-candidate.log');assert.equal(baseline.adjacencyBaselineRef,'3ef54e2');assert.equal(baseline.rows.length,5);assert.deepEqual(candidate.rows,baseline.rows);
writeFileSync(join(temp,'kplex-153-b5-work-comparison.json'),JSON.stringify({baseline,candidate},null,2)+'\n');console.log(JSON.stringify({cells:5,allWorkAndOrderedDigestsEqual:true,largest:candidate.rows.at(-1),sources:candidate.sources}));
