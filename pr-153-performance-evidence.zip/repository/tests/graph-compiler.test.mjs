/**
 * Tests K-Plex normalized-source compilation against the preserved migration golden and opaque
 * identity/revision contracts. Host-free transpiled modules and their temporary outputs are owned by the suite.
 * Arrow regressions retain neutral property inputs and reciprocal heading-link counts across
 * collection order. URL work-count probes forward real compiler operations and restore their temporary
 * instrumentation; membership regressions retain metadata duplicates, cancellation and terminal cleanup.
 */
import assert from "node:assert/strict";
import { spawnSync } from "node:child_process";
import { readFileSync } from "node:fs";
import { dirname, join, resolve } from "node:path";
import test from "node:test";
import { fileURLToPath, pathToFileURL } from "node:url";
import { loadPortableModules } from "./support/portableTypeScript.mjs";
import { neutralizeLegacyReferenceFixtures } from "./support/referenceCandidateFixture.mjs";
import { produceNormalizedFixtureRecords } from "./support/normalizedSourceFixture.mjs";
import { applyDefaultDateRoleFixture } from "./support/dateRoleFixture.mjs";
import { probeUrlAliasMembership } from "./support/urlAliasMembershipProbe.mjs";

const root = resolve(dirname(fileURLToPath(import.meta.url)), "..");
const loaded = loadPortableModules(['src/core/graph/compiler.ts', 'src/core/graph/model.ts', 'src/core/graph/source.ts', 'src/core/graph/relations.ts', 'src/core/graph/evidence.ts']);
const { directory: temp, entryPath: corePath, exports: core } = loaded;

const settings = {
  hierarchy: {
    hidden: ["hidden"],
    parents: ["Parent", "Parents", "up", "u", "North", "origin", "inception", "source", "parent domain"],
    children: ["Children", "Child", "down", "d", "South", "leads to", "contributes to", "nurtures"],
    leftFriends: ["Friends", "Friend", "Jump", "Jumps", "j", "similar", "supports", "alternatives", "advantages", "pros"],
    rightFriends: ["opposes", "disadvantages", "missing", "cons", "Challenger"],
    previous: ["Previous", "Prev", "West", "w", "Before"],
    next: ["Next", "n", "East", "e", "After"],
    exclusions: [],
  },
  inferAllLinksAsFriends: false,
  inverseInfer: false,
  showFullTagName: true,
  noteTypeField: "Note type",
  primaryTagField: "Note type",
  tagStyleList: ["#project", "#person"],
  maxLabelLength: 30,
};

const runtime = (overrides = {}) => ({
  now: () => 0,
  yield: async () => {},
  isCurrent: () => true,
  sliceBudgetMs: 10,
  resolverBatchSize: 400,
  ...overrides,
});

const boundary = (name = "fixture") => ({
  generation: core.sourceGeneration(`${name}:generation`),
  snapshotRevision: core.sourceSnapshotRevision(`${name}:snapshot`),
});

/** Consume bounded genuine source batches; optional instance observation never replaces compiler behavior. */
async function compileRecords(records, options = {}) {
  records = neutralizeLegacyReferenceFixtures(records);
  const compiler = new core.NormalizedGraphCompiler(options.settings ?? settings, options.runtime ?? runtime(), options.projection ?? "graph");
  options.observeCompiler?.(compiler);
  const readBoundary = options.boundary ?? boundary("compile");
  const read = compiler.beginRead(readBoundary);
  if (records.length === 0) {
    assert.equal(await compiler.acceptBatch(read, { boundary: readBoundary, sequence: 0, final: true, records: [] }), true);
  } else {
    for (let start = 0, sequence = 0; start < records.length; start += core.MAX_NORMALIZED_SOURCE_RECORDS_PER_BATCH, sequence += 1) {
      const batchRecords = records.slice(start, start + core.MAX_NORMALIZED_SOURCE_RECORDS_PER_BATCH);
      assert.equal(await compiler.acceptBatch(read, {
        boundary: readBoundary,
        sequence,
        final: start + batchRecords.length === records.length,
        records: batchRecords,
      }), true);
    }
  }
  assert.equal(compiler.completeRead(read, options.currentBoundary ?? readBoundary), options.expectComplete ?? true);
  return { compiler, compilation: options.expectComplete === false ? null : await (options.projection === "nodes" ? compiler.finishNodes() : compiler.finish()) };
}

const stableSort = (items) => items.map((item) => JSON.stringify(item)).sort();

for (const size of [256, 512, 1024, 2048, 4096]) {
  test(`URL membership seeds once for ${size} distinct labels and alias vocabularies`, /** Preserve exact first-seen vocabulary and independent evidence while attributing actual membership work. */ async () => {
    const source={id:core.nodeId('owner'),kind:'document',state:'materialized',semanticPath:'Owner.md',physicalPath:'Owner.md'};
    const target={id:core.nodeId('URL'),kind:'url',state:'synthetic',semanticPath:'https://shared.example/path'},sourceRevision=core.sourceRevision('membership');
    const records=[{kind:'entity',source,entity:source,sourceRevision,name:'Owner',url:null},
      ...Array.from({length:size},/** Keep label order, case, repeated/raw alias exclusions and occurrence count. */ (_,n)=>({kind:'body-url',source,sourceRevision,target:{entity:target,rawTarget:target.semanticPath,resolvedBy:'url'},label:`Label ${n}`,aliases:[`Label ${n}`,'Common','Common',target.semanticPath]}))];
    let probe,result;
    try {
      result=await compileRecords(records,{observeCompiler:/** Attach only to this private compiler's actual target array. */ compiler=>{probe=probeUrlAliasMembership(compiler,target.id);}});
      assert.equal(probe.counts.includesEntries,0);assert.equal(probe.counts.seedEntries,2);
      assert.equal(result.compiler.urlAliasMembership.size,0,'Finished compiler releases its temporary membership');
    } finally {probe?.restore();}
    assert.deepEqual(result.compilation.node(target.id).aliases,['Label 0','Common',...Array.from({length:size-1},/** Exact first-seen order, without sorting. */ (_,n)=>`Label ${n+1}`)]);
    assert.equal([...result.compilation.declarations()].length,size);
  });
}

test('interleaved semantic aliases retain duplicates and update URL membership', /** Metadata alias occurrence semantics remain independent of body-label deduplication. */ async()=>{
  const target={id:core.nodeId('URL'),kind:'url',state:'synthetic',semanticPath:'https://shared.example/path'},sourceRevision=core.sourceRevision('metadata');
  const body=/** Body labels deduplicate against the current complete alias vocabulary. */ label=>({kind:'body-url',source:target,sourceRevision,target:{entity:target,rawTarget:target.semanticPath,resolvedBy:'url'},label});
  const metadata=/** Metadata occurrences retain their original duplicate multiplicity. */ value=>({kind:'semantic-metadata',source:target,sourceRevision,metadataKind:'alias',value});
  const {compiler,compilation}=await compileRecords([body('First'),body('Second'),body('Third'),metadata('Metadata'),metadata('Metadata'),body('Metadata'),body('first'),body('First')]);
  assert.deepEqual(compilation.node(target.id).aliases,['First','Second','Third','Metadata','Metadata','first']);
  assert.equal(compilation.node(target.id).name,'First');assert.equal(compiler.urlAliasMembership.size,0);
});

test('dense metadata alias seeding cooperates, rejects and releases membership', /** Cancellation within initial membership construction cannot publish or retain partial state. */ async()=>{
  let clock=0,current=true,yields=0;
  const compiler=new core.NormalizedGraphCompiler(settings,runtime({now:/** Admit initial metadata before making the dense seed exceed its slice. */ ()=>clock,yield:async/** Cancel on the first actual seed checkpoint. */ ()=>{yields++;current=false;},isCurrent:/** Keep the terminal cancellation independent of the fake CPU clock. */ ()=>current}));
  const target={id:core.nodeId('URL'),kind:'url',state:'synthetic',semanticPath:'https://shared.example/path'},sourceRevision=core.sourceRevision('dense-metadata'),b=boundary('dense-metadata'),read=compiler.beginRead(b);
  for(let sequence=0;sequence<4;sequence++)assert(await compiler.acceptBatch(read,{boundary:b,sequence,final:false,records:Array.from({length:256},/** Real metadata occurrence ingestion seeds output before any URL membership exists. */ (_,n)=>({kind:'semantic-metadata',source:target,sourceRevision,metadataKind:'alias',value:`Alias ${sequence*256+n}`}))}));
  clock=100;
  assert.equal(await compiler.acceptBatch(read,{boundary:b,sequence:4,final:true,records:[{kind:'body-url',source:target,sourceRevision,target:{entity:target,rawTarget:target.semanticPath,resolvedBy:'url'},label:'New'}]}),false);
  assert.equal(yields,1);assert.equal(compiler.urlAliasMembership.size,0);assert.equal(await compiler.finish(),null);
});

test('node-only compilation and rejected batches release populated URL membership', /** Both terminal projections discard the private index while preserving output vocabulary. */ async()=>{
  const target={id:core.nodeId('URL'),kind:'url',state:'synthetic',semanticPath:'https://shared.example/path'},sourceRevision=core.sourceRevision('release');
  const records=['First','Second','Third'].map(/** Three distinct labels force private membership before either terminal path. */ label=>({kind:'body-url',source:target,sourceRevision,target:{entity:target,rawTarget:target.semanticPath,resolvedBy:'url'},label}));
  const {compiler,compilation}=await compileRecords(records,{projection:'nodes'});
  assert.deepEqual(compilation.nodes.get(target.id).aliases,['First','Second','Third']);assert.equal(compiler.urlAliasMembership.size,0);
  const rejected=new core.NormalizedGraphCompiler(settings,runtime()),b=boundary('reject-membership'),read=rejected.beginRead(b);
  assert(await rejected.acceptBatch(read,{boundary:b,sequence:0,final:false,records}));assert.equal(rejected.urlAliasMembership.size,1);
  assert.equal(await rejected.acceptBatch(read,{boundary:b,sequence:2,final:true,records:[]}),false);assert.equal(rejected.urlAliasMembership.size,0);
});

test("normalized compiler retains explicit arrow ownership across reciprocal heading-link input and batch order", async () => {
  const source = { id: core.nodeId("star"), kind: "document", state: "materialized", semanticPath: "A-Star.md", physicalPath: "A-Star.md" };
  const target = { id: core.nodeId("ucs"), kind: "document", state: "materialized", semanticPath: "Uniform Cost Search.md", physicalPath: "Uniform Cost Search.md" };
  const revision = core.sourceRevision("arrow:1");
  const valueId = core.referenceValueId("implements:1");
  const explicit = [
    { kind: "reference-value", source, sourceRevision: revision, valueId, fieldName: "Implements", normalizedFieldName: "implements", surface: "frontmatter", ordinal: 0, origin: "physical" },
    { kind: "reference-payload", source, sourceRevision: revision, valueId, index: 0, final: true, text: "[[Uniform Cost Search]]" },
    { kind: "reference-candidate", source, sourceRevision: revision, valueId, ordinal: 0, final: true,
      target: { entity: target, rawTarget: "Uniform Cost Search", resolvedBy: "host" }, hostOccurrenceCount: 1 },
  ];
  const ordinary = [
    { kind: "obsidian-link", source, sourceRevision: revision, target: { entity: target, rawTarget: "Uniform Cost Search#Related", resolvedBy: "host" }, occurrenceCount: 2 },
    { kind: "obsidian-link", source: target, sourceRevision: revision, target: { entity: source, rawTarget: "A-Star#Related", resolvedBy: "host" }, occurrenceCount: 1 },
  ];
  const entities = [source, target].map(entity => ({ kind: "entity", source: entity, sourceRevision: revision, entity, name: entity.semanticPath, url: null }));
  for (const explicitFirst of [true, false]) for (const inferAllLinksAsFriends of [true, false]) {
    const options = { settings: { ...settings, inferAllLinksAsFriends, hierarchy: { ...settings.hierarchy, leftFriends: ["Implements"] } } };
    const { compilation } = await compileRecords([...entities, ...(explicitFirst ? [...explicit, ...ordinary] : [...ordinary, ...explicit])], options);
    assert(compilation);
    const forward = [...compilation.node(source.id).neighbours.values()].find(relation => relation.target.id === target.id);
    const reverse = [...compilation.node(target.id).neighbours.values()].find(relation => relation.target.id === source.id);
    assert.equal(forward.direction, core.LinkDirection.FROM);
    assert.equal(reverse.direction, core.LinkDirection.TO);
    assert.equal(forward.isLeftFriend, true);
    assert.equal(reverse.isLeftFriend, true);
    assert.equal(forward.leftFriendType, core.RelationType.DEFINED);
    assert.equal([...compilation.declarations()].filter(item => item.sourceKind === "obsidian-link").length, 2);
    assert.equal([...compilation.declarations()].filter(item => item.fieldName === "Implements").length, 1);
  }
});
const optional = (key, value) => value === undefined ? {} : { [key]: value };

function cleanRelation(relation) {
  return {
    actualTargetPath: relation.target.semanticPath,
    direction: relation.direction,
    isHidden: relation.isHidden,
    isParent: relation.isParent,
    ...optional("parentType", relation.parentType),
    ...optional("parentTypeDefinition", relation.parentTypeDefinition),
    isChild: relation.isChild,
    ...optional("childType", relation.childType),
    ...optional("childTypeDefinition", relation.childTypeDefinition),
    isLeftFriend: relation.isLeftFriend,
    ...optional("leftFriendType", relation.leftFriendType),
    ...optional("leftFriendTypeDefinition", relation.leftFriendTypeDefinition),
    isRightFriend: relation.isRightFriend,
    ...optional("rightFriendType", relation.rightFriendType),
    ...optional("rightFriendTypeDefinition", relation.rightFriendTypeDefinition),
    isNextFriend: relation.isNextFriend,
    ...optional("nextFriendType", relation.nextFriendType),
    ...optional("nextFriendTypeDefinition", relation.nextFriendTypeDefinition),
    isPreviousFriend: relation.isPreviousFriend,
    ...optional("previousFriendType", relation.previousFriendType),
    ...optional("previousFriendTypeDefinition", relation.previousFriendTypeDefinition),
    targetPath: relation.target.semanticPath,
  };
}

function cleanPage(node) {
  return {
    aliases: [...node.aliases],
    isFolder: node.kind === "container",
    isTag: node.kind === "tag",
    maxLabelLength: node.maxLabelLength,
    name: node.name,
    noteType: node.noteType,
    path: node.semanticPath,
    physicalExtension: node.file?.extension ?? null,
    physicalPath: node.file?.path ?? null,
    primaryStyleTag: node.primaryStyleTag,
    relations: [...node.neighbours.values()].map(cleanRelation).sort((left, right) => left.targetPath.localeCompare(right.targetPath)),
    styleTags: [...node.styleTags],
    tags: [...node.tags],
    url: node.url,
  };
}

function semanticDeclaration(item) {
  return {
    sourcePath: item.sourcePath,
    targetPath: item.targetPath,
    role: item.role,
    relationType: item.relationType,
    direction: item.direction,
    declaredByPath: item.declaredByPath,
    declaredTargetPath: item.declaredTargetPath,
    declaredRole: item.declaredRole,
    sourceKind: item.sourceKind,
    ...optional("definition", item.definition),
    ...optional("fieldName", item.fieldName),
  };
}

test("portable full compiler matches the frozen pre-move compatibility graph semantics", async () => {
  const fixtureRoot = join(root, "tests/fixtures/excalibrain-indexing/Vault");
  const baseline = JSON.parse(readFileSync(join(root, "tests/fixtures/excalibrain-indexing/graph-baseline.json"), "utf8")).graph;
  const produced = produceNormalizedFixtureRecords(fixtureRoot).records;
  // Production structural collectors own materialized document/attachment/container entity facts.
  // Synthetic tag/URL/unresolved entity facts at the tail of this test producer are C11 contract
  // coverage only; the C13c compiler derives those targets from their occurrence records.
  const compatibilityRecords = produced.filter((record) => record.kind !== "entity"
    || ["document", "attachment", "container"].includes(record.entity.kind));
  // Mirror production family ordering: structural inventory is complete before aggregate host-link
  // summaries are consumed, while structural file/tag edges may still precede their entity facts.
  // The standalone C11 producer interleaves per-file host rows before appending folder topology.
  const familyRank = (record) => record.kind === "entity" || record.kind === "file-tree" || record.kind === "tag-tree" ? 0
    : record.kind === "obsidian-link" || record.kind === "unresolved-link" ? 1 : 2;
  const records = compatibilityRecords.map((record, index) => ({ record, index }))
    .sort((left, right) => familyRank(left.record) - familyRank(right.record) || left.index - right.index)
    .map(({ record }) => record);
  const { compilation } = await compileRecords(records);
  assert(compilation);

  const actualPages = [...compilation.nodes.values()]
    .map(cleanPage)
    .sort((left, right) => left.path.localeCompare(right.path));
  const expectedPages = [...baseline.pages]
    .map((page) => ({ ...page, relations: [...page.relations].sort((left, right) => left.targetPath.localeCompare(right.targetPath)) }))
    .sort((left, right) => left.path.localeCompare(right.path));
  // Deliberate product changes: every URL alias is searchable, and unconfigured scalar Dates
  // default to a DEFINED Parent. Preserve the frozen oracle for all non-Date relationships.
  for (const page of expectedPages) if (page.url) {
    page.aliases = [...new Set(records.filter(record => record.kind === "body-url"
      && record.target.entity.semanticPath === page.url && record.label && record.label !== page.url).map(record => record.label))];
  }
  const expectedEvidence = structuredClone(baseline.declarations);
  applyDefaultDateRoleFixture({ pages: expectedPages, declarations: expectedEvidence });
  assert.deepEqual(actualPages, expectedPages, "frozen-baseline compatibility except approved URL aliases and default Date role");

  const actualDeclarations = stableSort([...compilation.declarations()].map(semanticDeclaration));
  const expectedDeclarations = stableSort(expectedEvidence.map(semanticDeclaration));
  assert.deepEqual(actualDeclarations, expectedDeclarations, "declaration multiplicity/provenance stays frozen except approved Date role/type");
  assert.equal(compilation.legacyEvidence()?.declarationCount, baseline.declarations.length);
});

test("opaque NodeId is primary identity for pathless and case-distinct entities", async () => {
  const rev = core.sourceRevision("identity:1");
  const pathlessSource = { id: core.nodeId("opaque-source"), kind: "unresolved", state: "unresolved" };
  const pathlessTarget = { id: core.nodeId("opaque-target"), kind: "unresolved", state: "unresolved" };
  const upper = { id: core.nodeId("case-upper"), kind: "document", state: "materialized", semanticPath: "Case/Thing.md", physicalPath: "Case/Thing.md" };
  const lower = { id: core.nodeId("case-lower"), kind: "document", state: "materialized", semanticPath: "case/thing.md", physicalPath: "case/thing.md" };
  const records = [
    { kind: "entity", source: pathlessSource, sourceRevision: rev, entity: pathlessSource, name: "Pathless source", url: null },
    { kind: "entity", source: pathlessTarget, sourceRevision: rev, entity: pathlessTarget, name: "Pathless target", url: null },
    { kind: "inline-ontology", source: pathlessSource, sourceRevision: rev, target: { entity: pathlessTarget, rawTarget: "display-only", resolvedBy: "unresolved" }, provenance: { configuredFieldName: "Parent", normalizedFieldName: "parent", fieldName: "Parent", definition: "parent" } },
    { kind: "entity", source: upper, sourceRevision: rev, entity: upper, name: "Upper", url: null, file: { name: "Thing.md", extension: "md", path: "Case/Thing.md", mtime: 1 } },
    { kind: "entity", source: lower, sourceRevision: rev, entity: lower, name: "Lower", url: null, file: { name: "thing.md", extension: "md", path: "case/thing.md", mtime: 1 } },
    { kind: "inline-ontology", source: upper, sourceRevision: rev, target: { entity: lower, rawTarget: "case/thing", resolvedBy: "host" }, provenance: { configuredFieldName: "Parent", normalizedFieldName: "parent", fieldName: "Parent", definition: "parent" } },
  ];
  const { compilation } = await compileRecords(records);
  assert(compilation);
  assert.equal(compilation.nodes.size, 4);
  assert.equal(compilation.node(pathlessSource.id).semanticPath, undefined);
  assert.equal(compilation.node(pathlessTarget.id).semanticPath, undefined);
  assert.notEqual(compilation.node(upper.id), compilation.node(lower.id));
  assert.equal(compilation.node(upper.id).semanticPath, "Case/Thing.md");
  assert.equal(compilation.node(lower.id).semanticPath, "case/thing.md");
  assert.equal(compilation.node(pathlessSource.id).neighbours.size, 1);
  assert.equal([...compilation.node(pathlessSource.id).neighbours.values()][0].target.id, pathlessTarget.id);
  const pathlessEvidence = compilation.evidenceBetween(pathlessSource.id, pathlessTarget.id);
  assert.equal(pathlessEvidence.length, 1);
  assert.equal(pathlessEvidence[0].sourceId, pathlessSource.id);
  assert.equal(pathlessEvidence[0].targetId, pathlessTarget.id);
  assert.equal("sourcePath" in pathlessEvidence[0], false, "opaque IDs must never be projected as synthetic semantic paths");
  assert.equal("targetPath" in pathlessEvidence[0], false, "opaque IDs must never be projected as synthetic semantic paths");
  assert.equal(compilation.legacyEvidence(), null, "legacy path publication is intentionally unavailable for pathless portable graphs");
});

test("streaming accepts later materialized facts, ignores stale host-map rows, and rejects incoherent reads", async () => {
  const rev = core.sourceRevision("stream:1");
  const source = { id: core.nodeId("source-id"), kind: "document", state: "materialized", semanticPath: "A.md", physicalPath: "A.md" };
  const target = { id: core.nodeId("target-id"), kind: "document", state: "materialized", semanticPath: "B.md", physicalPath: "B.md" };
  const staleSource = { id: core.nodeId("stale-source"), kind: "document", state: "missing", semanticPath: "Deleted.md" };
  const staleTarget = { id: core.nodeId("stale-target"), kind: "document", state: "missing", semanticPath: "Gone.md" };
  const untrackedMaterializedTarget = { id: core.nodeId("untracked-target"), kind: "attachment", state: "materialized", semanticPath: "Loose.jpg", physicalPath: "Loose.jpg" };
  const fileTree = {
    kind: "file-tree", source, sourceRevision: rev,
    target: { entity: target, rawTarget: "B.md", resolvedBy: "structural" },
  };
  const records = [
    fileTree,
    { kind: "entity", source, sourceRevision: rev, entity: source, name: "A", url: null, file: { name: "A.md", extension: "md", path: "A.md", mtime: 1 } },
    { kind: "entity", source: target, sourceRevision: rev, entity: target, name: "B", url: null, file: { name: "B.md", extension: "md", path: "B.md", mtime: 1 } },
    { kind: "obsidian-link", source, sourceRevision: rev, target: { entity: target, rawTarget: "B", resolvedBy: "host" }, occurrenceCount: 1 },
    { kind: "obsidian-link", source: staleSource, sourceRevision: rev, target: { entity: target, rawTarget: "B", resolvedBy: "host" }, occurrenceCount: 1 },
    { kind: "obsidian-link", source, sourceRevision: rev, target: { entity: staleTarget, rawTarget: "Gone", resolvedBy: "host" }, occurrenceCount: 1 },
    { kind: "obsidian-link", source, sourceRevision: rev, target: { entity: untrackedMaterializedTarget, rawTarget: "Loose.jpg", resolvedBy: "host" }, occurrenceCount: 1 },
  ];
  const { compilation } = await compileRecords(records);
  assert(compilation);
  assert.equal(compilation.nodes.size, 2, "stale host-cache rows must not materialize deleted/missing graph nodes");
  assert.equal(compilation.node(source.id).neighbours.size, 1);
  assert.equal([...compilation.node(source.id).neighbours.values()][0].target.id, target.id);

  const compiler = new core.NormalizedGraphCompiler(settings, runtime());
  const expected = boundary("coherent");
  const wrong = boundary("changed");
  const read = compiler.beginRead(expected);
  assert.equal(await compiler.acceptBatch(read, { boundary: expected, sequence: 0, final: true, records: [] }), true);
  assert.equal(compiler.completeRead(read, wrong), false, "a changed generation/snapshot fence must reject publication");
  assert.equal(await compiler.finish(), null, "an unclosed incoherent read keeps all compiler state private");

  const incomplete = new core.NormalizedGraphCompiler(settings, runtime());
  const incompleteBoundary = boundary("missing-entity");
  const incompleteRead = incomplete.beginRead(incompleteBoundary);
  assert.equal(await incomplete.acceptBatch(incompleteRead, { boundary: incompleteBoundary, sequence: 0, final: true, records: [fileTree] }), true);
  assert.equal(incomplete.completeRead(incompleteRead, incompleteBoundary), true);
  assert.equal(await incomplete.finish(), null, "materialized references must have entity facts before a full result can publish");
});

test("Excalibrain.md has no reserved graph meaning", async () => {
  const rev = core.sourceRevision("ordinary-path:1");
  const source = { id: core.nodeId("ordinary-source"), kind: "document", state: "materialized", semanticPath: "A.md", physicalPath: "A.md" };
  const namedLikeOldSurface = { id: core.nodeId("ordinary-excalibrain"), kind: "document", state: "materialized", semanticPath: "Excalibrain.md", physicalPath: "Excalibrain.md" };
  const unresolved = { id: core.nodeId("ordinary-unresolved"), kind: "unresolved", state: "unresolved", semanticPath: "Missing.md" };
  const { compilation } = await compileRecords([
    { kind: "entity", source, sourceRevision: rev, entity: source, name: "A", url: null, file: { name: "A.md", extension: "md", path: "A.md", mtime: 1 } },
    { kind: "entity", source: namedLikeOldSurface, sourceRevision: rev, entity: namedLikeOldSurface, name: "Excalibrain", url: null, file: { name: "Excalibrain.md", extension: "md", path: "Excalibrain.md", mtime: 1 } },
    { kind: "obsidian-link", source, sourceRevision: rev, target: { entity: namedLikeOldSurface, rawTarget: "Excalibrain", resolvedBy: "host" }, occurrenceCount: 1 },
    { kind: "unresolved-link", source: namedLikeOldSurface, sourceRevision: rev, target: { entity: unresolved, rawTarget: "Missing", resolvedBy: "unresolved" }, occurrenceCount: 1 },
  ]);
  assert(compilation);
  assert.equal(compilation.evidenceBetween(source.id, namedLikeOldSurface.id).length, 1,
    "a same-named user note must remain a normal link target");
  assert.equal(compilation.evidenceBetween(namedLikeOldSurface.id, unresolved.id).length, 1,
    "a same-named user note must remain a normal link source");
});

test("compiler cancellation is checked after awaited yields and during cooperative resolution", async () => {
  const rev = core.sourceRevision("cancel:1");
  const source = { id: core.nodeId("cancel-source"), kind: "unresolved", state: "unresolved" };
  const target = { id: core.nodeId("cancel-target"), kind: "unresolved", state: "unresolved" };
  const record = { kind: "inline-ontology", source, sourceRevision: rev, target: { entity: target, rawTarget: "target", resolvedBy: "unresolved" }, provenance: { configuredFieldName: "Parent", normalizedFieldName: "parent", fieldName: "Parent" } };

  let current = true;
  let clock = 0;
  let yields = 0;
  const compiler = new core.NormalizedGraphCompiler(settings, runtime({
    now: () => (clock += 20),
    yield: async () => { yields += 1; current = false; },
    isCurrent: () => current,
    sliceBudgetMs: 1,
  }));
  const firstBoundary = boundary("cancel-batch");
  const read = compiler.beginRead(firstBoundary);
  assert.equal(await compiler.acceptBatch(read, { boundary: firstBoundary, sequence: 0, final: true, records: neutralizeLegacyReferenceFixtures([record]) }), false);
  assert.equal(yields, 1);
  assert.equal(await compiler.finish(), null);

  current = true;
  clock = 0;
  yields = 0;
  const resolverCompiler = new core.NormalizedGraphCompiler(settings, runtime({
    now: () => (clock += 8),
    yield: async () => { yields += 1; current = false; },
    isCurrent: () => current,
    sliceBudgetMs: 10_000,
    resolverBatchSize: 1,
  }));
  const secondBoundary = boundary("cancel-resolver");
  const secondRead = resolverCompiler.beginRead(secondBoundary);
  assert.equal(await resolverCompiler.acceptBatch(secondRead, { boundary: secondBoundary, sequence: 0, final: true, records: neutralizeLegacyReferenceFixtures([record]) }), true);
  assert.equal(resolverCompiler.completeRead(secondRead, secondBoundary), true);
  assert.equal(await resolverCompiler.finish(), null, "resolver cancellation after its awaited host yield must abort publication");
  assert(yields >= 1);
});

test("compiler reports bounded cooperative progress on a dense portable graph", async () => {
  const records = [];
  const rev = core.sourceRevision("dense:1");
  for (let index = 0; index < 600; index += 1) {
    const entity = { id: core.nodeId(`opaque-${index}`), kind: "unresolved", state: "unresolved" };
    records.push({ kind: "entity", source: entity, sourceRevision: rev, entity, name: `Node ${index}`, url: null });
  }
  let progress = 0;
  const { compilation } = await compileRecords(records, { runtime: runtime({ resolverBatchSize: 64, onProgress: () => { progress += 1; } }) });
  assert(compilation);
  assert.equal(compilation.nodes.size, 600);
  assert(progress > 0, "dense resolution must expose progress checkpoints without whole-vault publication");
});

test("portable compiler modules load without Obsidian or browser globals", () => {
  const result = spawnSync(process.execPath, ["--input-type=module", "-e", `
    import assert from "node:assert/strict";
    const core = await import(${JSON.stringify(pathToFileURL(corePath).href)});
    assert.equal(typeof globalThis.window, "undefined");
    assert.equal(typeof globalThis.document, "undefined");
    assert.equal(typeof globalThis.Worker, "undefined");
    const compiler = new core.NormalizedGraphCompiler(${JSON.stringify(settings)}, {
      now: () => 0, yield: async () => {}, isCurrent: () => true, sliceBudgetMs: 10, resolverBatchSize: 16,
    });
    assert.equal(typeof compiler.beginRead, "function");
  `], { cwd: temp, encoding: "utf8" });
  assert.equal(result.status, 0, result.stdout + result.stderr);
});

test("production GraphBuilder full build delegates normalized facts to the portable compiler", () => {
  const source = readFileSync(join(root, "src/index/GraphBuilder.ts"), "utf8");
  const buildStart = source.indexOf("  async build(options: Readonly<{ acquireSources?: boolean }> = {}): Promise<GraphState | null>");
  const settingsStart = source.indexOf("  private fullCompilerSettings()", buildStart);
  assert(buildStart >= 0 && settingsStart > buildStart);
  const body = source.slice(buildStart, settingsStart);
  for (const call of [
    "this.createFullCompiler()",
    "this.collectStructuralSources(compiler)",
    "this.collectHostLinkSources(compiler)",
    "this.collectMarkdownSources(compiler, options.acquireSources !== false)",
    "this.finalizeStructuralSources(compiler, structuralRead)",
    "compiler.finish()",
    "this.bindCompiledGraph(compiled, structuralRead.collector)",
  ]) assert(body.includes(call), `production full build must delegate through ${call}`);
  for (const removed of ["this.addStructuralSources(state)", "this.addHostLinkSources(state)", "this.enrichMarkdownPages(state)", "resolveEvidenceStoreCooperative("])
    assert(!body.includes(removed), `legacy full-build semantic path must not remain active: ${removed}`);
  assert(source.includes("new NormalizedSourcePatchPreparer("), "incremental preparation must reuse the portable semantic owner");
  assert(source.includes("this.prepareMarkdownSourcePatch(stagedState, file, meta)"), "the production patch path must delegate preparation before publication");
  assert(!source.includes("private consumeHostLinkRecord("), "the retired incremental host-link classifier must not remain active");
});

test("compiler rejection is terminal even if a producer retries the batch", async () => {
  const source = { id: core.nodeId("rejected-source"), kind: "unresolved", state: "unresolved" };
  const rev = core.sourceRevision("reject:1");
  const compiler = new core.NormalizedGraphCompiler(settings, runtime());
  const b = boundary("rejected");
  const read = compiler.beginRead(b);
  const invalid = { kind: "reference-candidate", source, sourceRevision: rev, valueId: "missing-header", ordinal: 0, final: true, hostOccurrenceCount: 0, target: { entity: source, rawTarget: "source", resolvedBy: "unresolved" } };
  const entity = { kind: "entity", source, sourceRevision: rev, entity: source, name: "Partial", url: null };
  assert.equal(await compiler.acceptBatch(read, { boundary: b, sequence: 0, final: true, records: [entity, invalid] }), false);
  assert.equal(await compiler.acceptBatch(read, { boundary: b, sequence: 0, final: true, records: [] }), false);
  assert.equal(await compiler.finish(), null, "a rejected read must never recover and publish its partially consumed records");
});

test("opaque identities containing delimiters remain distinct and retain contribution ownership", async () => {
  const rev = core.sourceRevision("opaque:1");
  const a = { id: core.nodeId("a\u0000b"), kind: "unresolved", state: "unresolved" };
  const b = { id: core.nodeId("c"), kind: "unresolved", state: "unresolved" };
  const records = [a, b].map(entity => ({ kind: "entity", source: entity, sourceRevision: rev, entity, name: String(entity.id), url: null }));
  records.push({ kind: "inline-ontology", source: a, sourceRevision: rev, target: { entity: b, rawTarget: "label", resolvedBy: "unresolved" }, provenance: { configuredFieldName: "Parent" } });
  const { compilation } = await compileRecords(records);
  assert(compilation);
  assert.equal(compilation.node(a.id).neighbours.size, 1);
  assert.equal([...compilation.node(a.id).neighbours.values()][0].target.id, b.id);
  const evidence = compilation.evidenceBetween(a.id, b.id);
  assert.equal(evidence.length, 1);
  assert.equal(evidence[0].contribution.sourceId, a.id);
  assert.equal(evidence[0].contribution.revision, rev);
});

test("URL display names preserve the legacy first meaningful label rule", async () => {
  const rev = core.sourceRevision("url-label:1");
  const source = { id: core.nodeId("url-source"), kind: "unresolved", state: "unresolved" };
  const url = "https://labels.example/item";
  const target = { id: core.nodeId("url-target"), kind: "url", state: "materialized", semanticPath: url };
  const records = [url, "Friendly label", "Later label", "Friendly label"].map(label => ({ kind: "body-url", source, sourceRevision: rev, target: { entity: target, rawTarget: url, resolvedBy: "url" }, label }));
  const { compilation } = await compileRecords(records);
  assert.equal(compilation.node(target.id).name, "Friendly label");
  assert.deepEqual(compilation.node(target.id).aliases, ["Friendly label", "Later label"], "Every defined URL label remains searchable, deduplicated");
});

test("pathless tag membership preserves the producer's exact tag identity", async () => {
  const rev = core.sourceRevision("tag-identity:1");
  const source = { id: core.nodeId("opaque-tag"), kind: "tag", state: "materialized" };
  const target = { id: core.nodeId("opaque-member"), kind: "unresolved", state: "unresolved" };
  const { compilation } = await compileRecords([{ kind: "tag-tree", source, sourceRevision: rev, target: { entity: target, rawTarget: "member", resolvedBy: "structural" }, membership: "entity-member", provenance: { rawValue: "#parent/child" } }]);
  assert(compilation.node(source.id));
  assert.equal(compilation.node(source.id).semanticPath, undefined);
  assert.equal(compilation.evidenceBetween(source.id, target.id)[0].declaredById, source.id);
});

test("derived tag ancestors cannot overwrite unrelated opaque identities", async () => {
  const rev = core.sourceRevision("tag-collision:1");
  const unrelated = { id: core.nodeId("tag:parent"), kind: "unresolved", state: "unresolved", semanticPath: "Unrelated" };
  const tag = { id: core.nodeId("explicit-child"), kind: "tag", state: "materialized", semanticPath: "tag:parent/child" };
  const member = { id: core.nodeId("member"), kind: "unresolved", state: "unresolved" };
  const { compilation } = await compileRecords([
    { kind: "entity", source: unrelated, sourceRevision: rev, entity: unrelated, name: "Unrelated", url: null },
    { kind: "tag-tree", source: tag, sourceRevision: rev, target: { entity: member, rawTarget: "member", resolvedBy: "structural" }, membership: "entity-member", provenance: { rawValue: "#parent/child" } },
  ]);
  assert.equal(compilation.node(unrelated.id).kind, "unresolved");
  assert.equal(compilation.node(unrelated.id).semanticPath, "Unrelated");
  assert.equal(compilation.node(unrelated.id).neighbours.size, 0);
  const parent = [...compilation.nodes.values()].find(node => node.semanticPath === "tag:parent");
  assert(parent);
  assert.notEqual(parent.id, unrelated.id);
  assert.equal(compilation.evidenceBetween(parent.id, tag.id).length, 1);
});

test("late tag facts preserve explicit identities after synthetic ancestors exist", async () => {
  const rev = core.sourceRevision("late-tag:1");
  const child = { id: core.nodeId("child-tag"), kind: "tag", state: "materialized", semanticPath: "tag:parent/child" };
  const parent = { id: core.nodeId("parent-tag"), kind: "tag", state: "materialized", semanticPath: "tag:parent" };
  const member = { id: core.nodeId("member"), kind: "unresolved", state: "unresolved" };
  const unrelated = { id: core.nodeId("\u0001kplex-derived-tag:1"), kind: "unresolved", state: "unresolved", semanticPath: "Elsewhere" };
  const membership = (source, rawValue) => ({ kind: "tag-tree", source, sourceRevision: rev, target: { entity: member, rawTarget: "member", resolvedBy: "structural" }, membership: "entity-member", provenance: { rawValue } });
  const { compilation } = await compileRecords([
    membership(child, "#parent/child"),
    { kind: "entity", source: unrelated, sourceRevision: rev, entity: unrelated, name: "Unrelated", url: null },
    membership(parent, "#parent"),
  ]);
  assert.equal(compilation.node(unrelated.id).semanticPath, "Elsewhere");
  assert.equal(compilation.node(unrelated.id).neighbours.size, 0);
  assert.equal(compilation.evidenceBetween(parent.id, child.id).length, 1);
  assert.equal(compilation.evidenceBetween(parent.id, member.id).length, 1);
});

test("tag hierarchy labels cannot reinterpret an explicit semantic path", async () => {
  const rev = core.sourceRevision("tag-path:1");
  const tag = { id: core.nodeId("tag-record-17"), kind: "tag", state: "materialized", semanticPath: "host-tag/17" };
  const member = { id: core.nodeId("member-17"), kind: "unresolved", state: "unresolved" };
  const { compilation } = await compileRecords([{ kind: "tag-tree", source: tag, sourceRevision: rev, target: { entity: member, rawTarget: "member", resolvedBy: "structural" }, membership: "entity-member", provenance: { rawValue: "#parent/child" } }]);
  assert.equal(compilation.node(tag.id).semanticPath, "host-tag/17");
  assert.equal(compilation.evidenceBetween(tag.id, member.id).length, 1);
});

test("portable evidence cannot fabricate a missing contribution revision", async () => {
  const rev = core.sourceRevision("ownership:1");
  const source = { id: core.nodeId("owner"), kind: "unresolved", state: "unresolved" };
  const target = { id: core.nodeId("target"), kind: "unresolved", state: "unresolved" };
  const { compilation } = await compileRecords([{ kind: "inline-ontology", source, sourceRevision: rev, target: { entity: target, rawTarget: "target", resolvedBy: "unresolved" }, provenance: { configuredFieldName: "Parent" } }]);
  const nodes = new Map([...compilation.nodes.values()].map(node => [node.id, node]));
  const keys = new Map([...compilation.nodes.keys()].map(id => [id, id]));
  const store = new core.RelationEvidenceStore();
  store.addPair(source.id, target.id, "parent", core.RelationType.DEFINED, core.LinkDirection.FROM, { sourceKind: "inline-ontology" });
  const unowned = new core.PortableGraphCompilation(compilation.nodes, compilation.discoveredFields, nodes, keys, store, new Map());
  assert.throws(() => [...unowned.declarations()], /no contribution ownership/);
});

/** Compare the vocabulary against full semantics across neutral policy selection, never a second oracle. */
test("node-only compilation preserves canonical vocabulary and facets without evidence or resolver work", async () => {
  const records = produceNormalizedFixtureRecords(join(root, "tests/fixtures/excalibrain-indexing/Vault")).records;
  for (const policy of [settings, { ...settings, hierarchy: { ...settings.hierarchy, parents: [], leftFriends: ["Parent", "Children"] },
    thumbnailProperty: "Friends", showFullTagName: false }]) {
    const full = await compileRecords(records, { settings: policy });
    let resolverProgress = 0;
    const nodes = await compileRecords(records, { settings: policy, projection: "nodes",
      runtime: runtime({ onProgress: () => { resolverProgress += 1; } }) });
    assert(nodes.compilation);
    const facets = (result) => [...result.nodes.values()].map(({ neighbours, ...node }) => node);
    assert.deepEqual(facets(nodes.compilation), facets(full.compilation));
    assert.deepEqual(nodes.compilation.discoveredFields, full.compilation.discoveredFields);
    assert.equal(nodes.compilation.kind, "node-metadata");
    assert.equal(nodes.compilation.declarations, undefined);
    assert.equal(resolverProgress, 0);
    assert.equal(nodes.compiler.evidence.declarationCount, 0);
    assert.equal(nodes.compiler.presentationCounts.size, 0);
    for (const node of nodes.compilation.nodes.values()) assert.equal(node.neighbours.size, 0);
    assert.equal(await nodes.compiler.finish(), null, "Node vocabulary cannot become complete graph authority");
  }
});

/** Terminal invalidation must discard the node projection just as it discards a full graph. */
test("node-only compilation rejects incomplete materialization, open reads and cancellation", async () => {
  const ref = { id: core.nodeId("opaque physical"), kind: "document", state: "materialized", physicalPath: "A.md" };
  const rev = core.sourceRevision("node-only:1");
  const incomplete = await compileRecords([{ kind: "field-name", source: ref, sourceRevision: rev,
    fieldName: "Unused", normalizedFieldName: "unused" }], { projection: "nodes" });
  assert.equal(incomplete.compilation, null);
  let current = true;
  const compiler = new core.NormalizedGraphCompiler(settings, runtime({ isCurrent: () => current }), "nodes");
  compiler.beginRead(boundary("node-only-open"));
  assert.equal(await compiler.finishNodes(), null);
  current = false;
  assert.equal(await compiler.finishNodes(), null);
  assert.equal(await new core.NormalizedGraphCompiler(settings, runtime()).finishNodes(), null);
});

/** Alias metadata affects node search facets only; evidence retains one primary provenance record. */
test("all URL aliases compile without changing primary label, line or relationship multiplicity", async () => {
  const source = { id: core.nodeId("A"), kind: "document", state: "materialized", semanticPath: "A.md", physicalPath: "A.md" };
  const target = { id: core.nodeId("URL"), kind: "url", state: "synthetic", semanticPath: "https://help.obsidian.md" };
  const rev = core.sourceRevision("aliases:1");
  const entity = { kind: "entity", source, sourceRevision: rev, entity: source, name: "A", url: null };
  const record = { kind: "body-url", source, sourceRevision: rev, target: { entity: target, rawTarget: target.semanticPath, resolvedBy: "url" }, label: "Second", provenance: { surface: "body", location: { line: 1 } } };
  const baseline = (await compileRecords([entity, record])).compilation;
  const complete = (await compileRecords([entity, { ...record, aliases: ["First", "Second", "Third"] }])).compilation;
  assert.deepEqual([...complete.declarations()], [...baseline.declarations()]);
  assert.equal(complete.evidenceBetween(source.id, target.id).length, 1);
  const node = complete.nodes.get(target.id);
  assert.equal(node.name, "Second"); assert.deepEqual(node.aliases, ["Second", "First", "Third"]);
});

/** One URL's dense alias vocabulary must yield and reject cancellation before publication. */
test("dense URL alias accumulation cooperates within one normalized record", async () => {
  let current = true, yields = 0;
  const compiler = new core.NormalizedGraphCompiler(settings, runtime({ now: () => 100, sliceBudgetMs: 0,
    yield: async () => { yields++; current = false; }, isCurrent: () => current }));
  const b = boundary("dense-aliases"), read = compiler.beginRead(b), rev = core.sourceRevision("dense:1");
  const source = { id: core.nodeId("A"), kind: "document", state: "materialized", semanticPath: "A.md", physicalPath: "A.md" };
  const target = { id: core.nodeId("URL"), kind: "url", state: "materialized", semanticPath: "https://help.obsidian.md" };
  assert.equal(await compiler.acceptBatch(read, { boundary: b, sequence: 0, final: true, records: [
    { kind: "body-url", source, sourceRevision: rev, target: { entity: target, rawTarget: target.semanticPath, resolvedBy: "url" }, aliases: Array.from({ length: 4096 }, (_, i) => `Alias ${i}`) },
  ] }), false);
  assert.equal(yields, 1);
});

/** Canonical origin identity groups subpaths while opaque-equal root facts never form self-edges. */
test("canonical URL root is parent of distinct subpaths without a self relationship", async () => {
  const source = { id: core.nodeId("opaque owner"), kind: "document", state: "materialized", semanticPath: "Owner.md", physicalPath: "Owner.md" };
  const root = { id: core.nodeId("opaque root"), kind: "url", state: "synthetic", semanticPath: "https://obsidian.md" };
  const target = (id, path) => ({ id: core.nodeId(id), kind: "url", state: "synthetic", semanticPath: path });
  const slug1 = target("opaque first", "https://obsidian.md/slug1"), slug2 = target("opaque second", "https://obsidian.md/slug2");
  const sourceRevision = core.sourceRevision("url-origin:1");
  const urlReference = entity => ({ entity, rawTarget: entity.semanticPath, resolvedBy: "url" });
  const body = entity => ({ kind: "body-url", source, sourceRevision, target: urlReference(entity), origin: urlReference(root) });
  const { compilation } = await compileRecords([
    { kind: "entity", source, sourceRevision, entity: source, name: "Owner", url: null },
    body(root), body(slug1), body(slug2), body(slug1),
  ]);
  const origins = [...compilation.declarations()].filter(record => record.sourceKind === "url-origin");
  assert.equal(origins.length, 2, "repeated subpath occurrence does not duplicate shared origin hierarchy");
  assert.deepEqual(origins.map(record => [record.sourceId, record.targetId]).sort(), [[root.id, slug1.id], [root.id, slug2.id]].sort());
  assert.equal(compilation.evidenceBetween(root.id, root.id).length, 0, "legacy equal-origin fact has no self evidence");
  assert.equal([...compilation.nodes.get(root.id).neighbours.values()].find(relation => relation.target.id === slug1.id).isChild, true);
  assert.equal([...compilation.nodes.get(slug2.id).neighbours.values()].find(relation => relation.target.id === root.id).isParent, true);
});

/** Raw URL declarations and opaque target identities remain separate from canonical presentation. */
test("canonical URL materialization preserves raw source facts without default-spelling aliases", async () => {
  const source = { id: core.nodeId("owner"), kind: "document", state: "materialized", semanticPath: "Owner.md", physicalPath: "Owner.md" };
  const target = { id: core.nodeId("opaque URL"), kind: "url", state: "synthetic", semanticPath: "https://obsidian.md" };
  const revision = core.sourceRevision("raw-url:1");
  const raw = "https://Obsidian.md/";
  const record = { kind: "body-url", source, sourceRevision: revision, target: { entity: target, rawTarget: raw, resolvedBy: "url" }, label: raw,
    aliases: [raw, "Documentation"], provenance: { surface: "body", rawValue: raw, location: { line: 3 } } };
  const { compilation } = await compileRecords([{ kind: "entity", source, sourceRevision: revision, entity: source, name: "Owner", url: null }, record]);
  const node = compilation.nodes.get(target.id);
  assert.equal(node.id, "opaque URL"); assert.equal(node.semanticPath, "https://obsidian.md"); assert.equal(node.url, "https://obsidian.md");
  assert.equal(node.name, "https://obsidian.md"); assert.deepEqual(node.aliases, ["Documentation"]);
  assert.equal(record.target.rawTarget, raw); assert.equal(record.provenance.rawValue, raw);
  const pathless = { ...target, id: core.nodeId("pathless URL") }; delete pathless.semanticPath;
  const result = await compileRecords([{ kind: "entity", source, sourceRevision: revision, entity: source, name: "Owner", url: null },
    { ...record, target: { ...record.target, entity: pathless }, label: undefined, aliases: [] }]);
  assert.equal(result.compilation.nodes.get(pathless.id).url, raw);
});

/** Repeated URLs need neither source-name derivation nor an alias index when no aliases were supplied. */
test("repeated body URLs allocate alias membership only for populated vocabularies", async () => {
  const source = { id: core.nodeId("opaque owner"), kind: "document", state: "materialized", semanticPath: "Folder/Owner.md", physicalPath: "Folder/Owner.md" };
  const target = { id: core.nodeId("opaque URL"), kind: "url", state: "unresolved", semanticPath: "https://obsidian.md" };
  const revision = core.sourceRevision("url-work:1"), b = boundary("url-work");
  const compiler = new core.NormalizedGraphCompiler(settings, runtime()), read = compiler.beginRead(b);
  const originalSet = globalThis.Set, aliasArrays = new WeakSet();
  const originalEnsureNode = compiler.ensureNode, originalFallbackName = compiler.fallbackName;
  let aliasIndexes = 0, sourceFallbacks = 0;
  /** Observe only membership indexes over actual URL alias arrays; all Set behavior is inherited. */
  class ObservedSet extends originalSet {
    /** Forward native construction and count the known private alias-array identity. */
    constructor(values) {
      super(values);
      if (values && aliasArrays.has(values)) aliasIndexes++;
    }
  }
  /** Capture actual node arrays after the unchanged identity/materialization operation returns. */
  compiler.ensureNode = function (...args) {
    const node = originalEnsureNode.apply(this, args);
    if (node?.id === target.id) aliasArrays.add(node.aliases);
    return node;
  };
  /** Count source fallback computations while preserving their actual values. */
  compiler.fallbackName = function (...args) {
    if (args[0].id === source.id) sourceFallbacks++;
    return originalFallbackName.apply(this, args);
  };
  const entity = { kind: "entity", source, sourceRevision: revision, entity: source, name: "", url: null };
  const record = { kind: "body-url", source, sourceRevision: revision,
    target: { entity: target, rawTarget: target.semanticPath, resolvedBy: "url" }, label: "Primary" };
  const ordinary = Array.from({ length: 600 }, (_, index) => ({ ...record,
    ...(index % 2 ? { aliases: [] } : {}), provenance: { surface: "body", location: { line: index + 1 } } }));
  try {
    globalThis.Set = ObservedSet;
    const records = [entity, ...ordinary];
    let sequence = 0;
    for (let start = 0; start < records.length; start += core.MAX_NORMALIZED_SOURCE_RECORDS_PER_BATCH) {
      assert.equal(await compiler.acceptBatch(read, { boundary: b, sequence: sequence++, final: false,
        records: records.slice(start, start + core.MAX_NORMALIZED_SOURCE_RECORDS_PER_BATCH) }), true);
    }
    assert.equal(sourceFallbacks, 0, "the explicit empty source name never needs a fallback");
    assert.equal(aliasIndexes, 0, "absent and empty alias vocabularies create no membership index");
    assert.equal(await compiler.acceptBatch(read, { boundary: b, sequence, final: true, records: [
      { ...record, label: "Secondary", aliases: ["Third", "Primary", "Third", target.semanticPath],
        provenance: { surface: "body", location: { line: 601 } } },
    ] }), true);
    assert.equal(aliasIndexes, 1, "a supplied vocabulary still receives its exact deduplication index");
  } finally {
    globalThis.Set = originalSet;
    compiler.ensureNode = originalEnsureNode;
    compiler.fallbackName = originalFallbackName;
  }
  assert.equal(compiler.completeRead(read, b), true);
  const compilation = await compiler.finish();
  assert.ok(compilation);
  assert.equal(compilation.nodes.get(source.id).name, "", "explicitly empty entity names remain empty");
  assert.equal(compilation.nodes.get(target.id).name, "Primary");
  assert.deepEqual(compilation.nodes.get(target.id).aliases, ["Primary", "Secondary", "Third"]);
  const declarations = [...compilation.declarations()];
  assert.equal(declarations.length, 601, "each occurrence keeps independent evidence");
  assert.deepEqual(declarations.map(item => item.line).sort((a, b) => a - b), Array.from({ length: 601 }, (_, i) => i + 1));
});

/** Lazy source fallback keeps explicit semantic paths and pathless opaque identities distinct. */
test("new body URL sources derive a fallback once without interpreting opaque IDs", async () => {
  for (const [kind, semanticPath, expected] of [
    ["document", "Folder/Owner.md", "Owner"], ["container", "Folder/Group", "Group"],
    ["tag", "tag:Group/Leaf", "Leaf"], ["url", "https://obsidian.md/source", "https://obsidian.md/source"],
    ["document", undefined, ""], ["url", undefined, ""],
  ]) {
    const source = { id: core.nodeId(`opaque/${kind}.md`), kind, state: "unresolved",
      ...(semanticPath === undefined ? {} : { semanticPath }) };
    const target = { id: core.nodeId("opaque target"), kind: "url", state: "unresolved", semanticPath: "https://obsidian.md/target" };
    const compiler = new core.NormalizedGraphCompiler(settings, runtime()), b = boundary(`fallback-${kind}-${expected}`);
    const read = compiler.beginRead(b), revision = core.sourceRevision("fallback:1");
    const fallback = compiler.fallbackName;
    let fallbacks = 0;
    /** Count actual source-name derivations; target names are explicitly producer-derived. */
    compiler.fallbackName = function (...args) {
      if (args[0].id === source.id) fallbacks++;
      return fallback.apply(this, args);
    };
    try {
      assert.equal(await compiler.acceptBatch(read, { boundary: b, sequence: 0, final: true,
        records: Array.from({ length: 64 }, (_, index) => ({ kind: "body-url", source, sourceRevision: revision,
          target: { entity: target, rawTarget: "https://Obsidian.md/target", resolvedBy: "url" },
          provenance: { surface: "body", location: { line: index + 1 } } })) }), true);
      assert.equal(fallbacks, 1, "only initial source-node creation derives a name");
    } finally { compiler.fallbackName = fallback; }
    assert.equal(compiler.completeRead(read, b), true);
    const compilation = await compiler.finish();
    assert.ok(compilation);
    assert.equal(compilation.nodes.get(source.id).name, expected);
    assert.equal(compilation.nodes.get(source.id).semanticPath, semanticPath);
    assert.equal([...compilation.declarations()].length, 64);
  }
});
