﻿/** Summarize completed raw startup trials without changing measurements or substituting counters for elapsed time. */
import {readFileSync,readdirSync,writeFileSync} from 'node:fs';
import {join} from 'node:path';
const root=join(process.env.TEMP,'kplex-163-large-restarts'),results=[];
for(const name of readdirSync(root).filter(/** Ignore staging, setup and incomplete observers. */ name=>name.endsWith('.json')&&!name.startsWith('original-'))){
 const r=JSON.parse(readFileSync(join(root,name),'utf8').replace(/^\uFEFF/,''));
 if(r.action!=='run'||!['passed','failed-startup','failed-reuse','failed'].includes(r.status)||!r.final)continue;
 const s=r.final,stream=join(root,r.sampleStream??name.replace(/\.json$/,'.samples.jsonl'));
 const samples=readFileSync(stream,'utf8').trim().split('\n').map(/** Preserve exact raw observations. */ row=>JSON.parse(row)).filter(/** Only the new renderer belongs to this trial. */ row=>row.timeOrigin===s.timeOrigin);
 const d=s.startup,at=d.startedAtMs;
 results.push({file:name,status:r.status,explanation:r.explanation??null,observedUntilNavigationMs:r.observedUntilNavigationMs??null,mainSha256:r.artifacts['main.js'],driverSha256:r.driverSha256,lifecycle:r.lifecycle,rendererChanged:r.rendererChanged,
  allForeground:r.allForeground,focus:r.foregroundByOrigin,observations:samples.length,firstReadyMs:r.firstReadyFromNavigationMs,settledMs:r.readyFromNavigationMs,
  firstObserved:r.firstObservedByOrigin[s.timeOrigin],diagnosticsEnabled:d.enabled,
  exactMilestones:Object.fromEntries(Object.entries(d.milestones).map(/** Put detailed plugin-relative events on the renderer clock without summing overlapping lanes. */ ([key,value])=>[key,at+value])),
  phases:d.phases.map(/** Each same-lane interval is exclusive; source and hydration lanes can overlap. */ p=>({lane:p.lane,phase:p.phase,pass:p.pass,startMs:at+p.startedMs,endMs:p.endedMs===null?null:at+p.endedMs,durationMs:p.endedMs===null?null:p.endedMs-p.startedMs,processed:p.processed,total:p.total,counters:p.counters})),
  hydration:s.hydration,graph:s.graph,semantic:s.startup.semantic,semanticActivity:s.semanticActivity??null,scheduler:s.scheduler??null,source:s.source,url:s.url,sourceRepository:s.sourceRepository,semanticDependencies:s.semanticDependencies,
  visible:s.visible,mode:s.mode,saved:s.saved,host:s.host,
  heapMaximumSampleBytes:Math.max(...samples.map(/** Sampled process heap is neither retained memory nor a proven peak. */ row=>row.heapUsedBytes)),
  maxObservedRendererTaskGapMs:Math.max(...samples.map(/** Timer starts only at the first observation, never measures pre-observation stalls or paint. */ row=>row.heartbeat?.maxGapMs??0))});
}
const output=join(process.env.TEMP,'kplex-163-native-summary.json');
writeFileSync(output,JSON.stringify({generatedAt:new Date().toISOString(),method:'Native app:reload; Electron retained. Polling bounds differ from exact detailed-profile milestones. Source/hydration intervals overlap. Sampled heap is not forced-GC retention or a proven peak.',results},null,2)+'\n');
console.log(JSON.stringify(results.map(/** Keep console output compact. */ ({file,firstReadyMs,settledMs,hydration,graph,allForeground})=>({file,firstReadyMs,settledMs,route:hydration.route,attempts:hydration.attempts,full:graph.full,allForeground}))));
