/** Audit only the two authorized disposable windows and explicit plugin artifacts after validation. */
import {createHash} from 'node:crypto';
import {existsSync,readFileSync,realpathSync,writeFileSync} from 'node:fs';
import {join} from 'node:path';
import {obsidianCliExecutable,spawnNativeSync} from 'file:///C:/Users/viczi/GitHub/kplex/scripts/testing/obsidian/processTools.mjs';
const root='C:/Users/viczi/GitHub/kplex',temp=process.env.TEMP,results=[];
/** Hash a named executable or configuration file without enumerating vault contents. */
function hash(path){return createHash('sha256').update(readFileSync(path)).digest('hex');}
/** Keep the named-vault audit transport bounded and omit arbitrary host output on failure. */
function cli(vault,command,...args){const r=spawnNativeSync(obsidianCliExecutable(),[`vault=${vault}`,command,...args],{cwd:root,encoding:'utf8',timeout:30000,killSignal:'SIGKILL',maxBuffer:2*1024*1024});if(r.error||r.status!==0||/^Error:/m.test(r.stdout??''))throw Error('Disposable audit transport failed');return r.stdout.trim();}
for(const vault of ['kplex-test','kplex-test-small']){
 const path=realpathSync(join('C:/Obsidian',vault)),reported=cli(vault,'vault','info=path').replace(/^path\s+/,'');
 if(realpathSync(reported)!==path)throw Error('Different disposable vault selected');
 const raw=cli(vault,'eval',`code=(/** Observe aggregate state and owned test resources without changing focus or plugin state. */ ()=>{const p=app.plugins.plugins['k-plex'],w=require('@electron/remote').getCurrentWindow();return JSON.stringify({loaded:!!p,enabled:app.plugins.enabledPlugins.has('k-plex'),configDir:app.vault.configDir,throttling:w.webContents.getBackgroundThrottling(),ownedRestartProbe:!!window.kplexRestartProbe,ownedRestartHeartbeat:!!window.kplexRestartHeartbeat,ownedForegroundController:!!window.__kplexForegroundTest,indexingMode:p?.settings.indexingMode,detailedDiagnostics:p?.getStartupDiagnostics().enabled,status:p?.getIndexStatus().phase})})()`);
 const state=JSON.parse(raw.slice(raw.indexOf('{')));if(state.configDir!=='.obsidian')throw Error('Unexpected test config directory');delete state.configDir;
 const plugin=join(path,'.obsidian/plugins/k-plex'),artifacts={};
 for(const file of ['main.js','manifest.json','styles.css']){artifacts[file]=hash(join(plugin,file));if(artifacts[file]!==hash(join(root,'dist',file)))throw Error('Installed artifact differs from verified build');}
 const stagedArtifactRemains=existsSync(join(plugin,'main.js.restart-staged'));
 if(!state.loaded||!state.enabled||!state.throttling||state.ownedRestartProbe||state.ownedRestartHeartbeat||state.ownedForegroundController||state.detailedDiagnostics||stagedArtifactRemains)throw Error('Test resource or plugin state audit failed');
 let configurationRestored=null;
 if(vault==='kplex-test'){
  configurationRestored=hash(join(plugin,'data.json'))===hash(join(temp,'kplex-163-large-restarts/original-data.json'))&&hash(join(path,'.obsidian/community-plugins.json'))===hash(join(temp,'kplex-163-large-restarts/original-community-plugins.json'));
  if(!configurationRestored)throw Error('Large test vault original configuration differs');
 }
 results.push({vault,state,artifacts,stagedArtifactRemains,configurationRestored});
}
const result={at:new Date().toISOString(),status:'passed',personalVaultAccess:false,noteContentAccess:false,vaultWrites:false,results};
writeFileSync(join(temp,'kplex-163-final-audit.json'),JSON.stringify(result,null,2)+'\n');console.log(JSON.stringify(result));
