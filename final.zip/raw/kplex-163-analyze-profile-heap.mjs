﻿/** Locate observed heap maxima in already completed raw trials without changing native execution. */
import {readFileSync,writeFileSync} from 'node:fs';import {join} from 'node:path';
const root=join(process.env.TEMP,'kplex-163-large-restarts'),results=[];
for(const file of ['profile-baseline-application-reload','profile-structural-candidate-application-reload']){
 const rows=readFileSync(join(root,file+'.samples.jsonl'),'utf8').trim().split('\n').map(/** Preserve each raw aggregate sample. */ line=>JSON.parse(line));
 const origin=rows.at(-1).timeOrigin,samples=rows.filter(/** Ignore the old renderer's pre-reload observation. */ row=>row.timeOrigin===origin);
 const peak=samples.reduce(/** Retain the actual sampled maximum rather than estimating retention. */ (best,row)=>row.heapUsedBytes>best.heapUsedBytes?row:best);
 results.push({file,peak:{now:peak.now,bytes:peak.heapUsedBytes,hydration:peak.hydration,graph:peak.graph,source:peak.source,semantic:peak.startup.semantic,progress:peak.startup.progress},final:{now:samples.at(-1).now,bytes:samples.at(-1).heapUsedBytes}});
}
writeFileSync(join(process.env.TEMP,'kplex-163-profile-heap-observations.json'),JSON.stringify({method:'Unforced sampled renderer heap, not retained memory or proven peak; different completion routes/coverage prevent attributing the difference solely to this change.',results},null,2)+'\n');
console.log(JSON.stringify(results.map(/** Keep analysis output scalar. */ r=>({file:r.file,peakAtSeconds:r.peak.now/1000,peakBytes:r.peak.bytes,peakPhase:r.peak.hydration.phase,fullBuilds:r.peak.semantic.fullBuilds,finalBytes:r.final.bytes}))));
