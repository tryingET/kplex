﻿/** Recover the exact pre-comment source used by earlier finished measurements; reject any byte mismatch. */
import {readFileSync,writeFileSync,mkdirSync} from 'node:fs';import {join} from 'node:path';import {createHash} from 'node:crypto';
let source=readFileSync('src/index/GraphIndex.ts','utf8');
source=source.replace(/   \* Optional foreground proof must match saved owner fingerprints before even page-only publication\.\r?\n   \* Only an actual zero-page cancellation after publication supersession is reported as retryable;\r?\n   \* the caller owns admission of a new candidate, never revival of this one or source authority\.\r?\n/,'');
for(const text of ['/** Every intervening source must equal its saved semantic value. */ ','/** Detect equal-sized file membership replacement. */ ','/** Folder membership has its own physical validity fence. */ ']){if(!source.includes(text))throw Error('Missing exact comment');source=source.replace(text,'');}
const sha=createHash('sha256').update(source).digest('hex');if(sha!=='058684e120bff59467f87ce1739051e59bdbd12363bf8d798d9d06d617520868')throw Error('Historical source mismatch '+sha);
const out=join(process.env.TEMP,'kplex-163-source-before-review');mkdirSync(out,{recursive:true});writeFileSync(join(out,'GraphIndex.ts'),source);console.log(JSON.stringify({sha256:sha,reconstructedExactly:true}));
