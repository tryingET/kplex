/** Derive production-only startup and sampled-memory results from immutable completed native streams. */
import {createHash} from 'node:crypto';
import {readFileSync,writeFileSync} from 'node:fs';
import {join} from 'node:path';
const directory=join(process.env.TEMP,'kplex-163-large-restarts'),trials=[];
/** Identify the complete raw source bytes independently of this derived summary. */
function hash(bytes){return createHash('sha256').update(bytes).digest('hex');}
/** Report the middle observed value without deriving a before/after speedup. */
function median(values){return [...values].sort(/** Numeric order only. */ (a,b)=>a-b)[Math.floor(values.length/2)];}
for(const number of [1,2,3]){
 const label=`production-application-reload-${number}`,reportBytes=readFileSync(join(directory,label+'.json')),streamBytes=readFileSync(join(directory,label+'.samples.jsonl'));
 const r=JSON.parse(reportBytes),s=r.final,samples=streamBytes.toString().trim().split('\n').map(/** Parse every original observation. */ line=>JSON.parse(line)).filter(/** Exclude the old renderer's pre-reload sample. */ sample=>sample.timeOrigin===s.timeOrigin);
 if(r.status!=='passed'||!r.rendererChanged||!r.allForeground||r.cleanupUnavailable||s.startup.enabled||!s.status.upToDate||s.inventory||s.building||!s.semanticDependencies||!s.visible.expectedDemand||!s.visible.expectedCenter)throw Error('Production acceptance failed');
 if(s.hydration.route!=='full-snapshot'||s.hydration.outcome!=='complete'||s.hydration.attempts!==2||s.hydration.pages!==108217||s.hydration.relations!==108217||s.hydration.evidence!==197561||s.graph.fingerprints!==20088)throw Error('Incomplete saved graph');
 // Acquisition counters count operations, so legitimate repeated checks can exceed unique fingerprints.
 if(s.source.vaultReads||s.source.parses||s.source.repaired||s.url.reads||s.source.reusedBodies<20088||s.source.reusedBodies!==s.source.checked)throw Error('Unexpected source work');
 const peak=samples.reduce(/** Retain the largest observed sample without claiming a true peak. */ (a,b)=>b.heapUsedBytes>a.heapUsedBytes?b:a);
 const observed=r.firstObservedByOrigin[s.timeOrigin];
 trials.push({label,sourceReportSha256:hash(reportBytes),sourceStreamSha256:hash(streamBytes),productionMainSha256:r.artifacts['main.js'],driverSha256:r.driverSha256,firstObservedNavigationMs:observed.fullNavigable,firstObservedFullGraphMs:observed.fullGraph,firstReadyMs:r.firstReadyFromNavigationMs,settledMs:r.readyFromNavigationMs,heapMaximumSampleBytes:peak.heapUsedBytes,heapMaximumSampleAtMs:peak.now,heapFinalSampleBytes:s.heapUsedBytes,maxObservedRendererTaskGapMs:Math.max(...samples.map(/** Timer gaps start at the first observation. */ sample=>sample.heartbeat?.maxGapMs??0)),fullBuilds:s.startup.semantic.fullBuilds,restoredPages:s.hydration.pages,restoredRelations:s.hydration.relations,restoredEvidence:s.hydration.evidence,reusedBodies:s.source.reusedBodies,sourceReads:s.source.vaultReads,sourceParses:s.source.parses,sourceRepairs:s.source.repaired,urlReads:s.url.reads,allForeground:r.allForeground,detailedDiagnostics:s.startup.enabled});
}
const result={generatedAt:new Date().toISOString(),status:'passed',method:'Three sequential foreground vault-window app:reload trials; Electron retained. Publication observations are polling bounds, not paint. Heap samples are unforced process observations, not retained memory or proven peaks. No successful native baseline exists for a speedup percentage.',trials,medians:Object.fromEntries(['firstObservedNavigationMs','firstObservedFullGraphMs','firstReadyMs','settledMs','heapMaximumSampleBytes','heapFinalSampleBytes','maxObservedRendererTaskGapMs'].map(/** Compare the same metric across all three successful production trials. */ key=>[key,median(trials.map(/** Select one finite observed metric. */ row=>row[key]))]))};
writeFileSync(join(process.env.TEMP,'kplex-163-production-summary.json'),JSON.stringify(result,null,2)+'\n');console.log(JSON.stringify(result));
