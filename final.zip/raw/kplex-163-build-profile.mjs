/** Build matched test-only profiling artifacts in memory; shipping source/dist remain unchanged. */
import {readFileSync,writeFileSync,mkdirSync} from 'node:fs';
import {join,resolve} from 'node:path';
import {builtinModules} from 'node:module';
import {createHash} from 'node:crypto';
import esbuild from 'file:///C:/Users/viczi/GitHub/kplex/node_modules/esbuild/lib/main.js';
const root='C:/Users/viczi/GitHub/kplex',out=join(process.env.TEMP,'kplex-163-profile-artifacts');mkdirSync(out,{recursive:true});
const source=readFileSync(join(root,'src/main.ts'),'utf8');
const before='this.startupDiagnostics.begin((window as Window & { kplexStartupDiagnosticsEnabled?: boolean }).kplexStartupDiagnosticsEnabled === true);';
if(source.split(before).length!==2)throw Error('Unexpected diagnostics entry point');
const main=source.replace(before,'this.startupDiagnostics.begin(true);');
writeFileSync(join(out,'main.profile.ts'),main);
const results=[];
for(const mode of ['baseline','candidate']){
 const mappings=new Map([[resolve(root,'src/main.ts'),main]]);
 if(mode==='baseline')for(const [path,name] of [['src/index/GraphIndex.ts','GraphIndex.ts'],['src/index/IndexedDbCache.ts','IndexedDbCache.ts'],['src/application/supportReportProjection.ts','supportReportProjection.ts']])mappings.set(resolve(root,path),readFileSync(join(process.env.TEMP,'kplex-163-diagnostic-source',name),'utf8'));
 const result=await esbuild.build({absWorkingDir:root,banner:{js:'/* K-Plex - generated bundle */'},entryPoints:['src/main.ts'],bundle:true,resolveExtensions:['.ts','.tsx','.js','.jsx','.css','.json'],external:['obsidian','electron','@codemirror/autocomplete','@codemirror/collab','@codemirror/commands','@codemirror/language','@codemirror/lint','@codemirror/search','@codemirror/state','@codemirror/view','@lezer/common','@lezer/highlight','@lezer/lr',...builtinModules],format:'cjs',target:'es2021',sourcemap:false,treeShaking:true,minify:true,write:false,outfile:'dist/main.js',plugins:[{name:'test-only-profile',setup(build){build.onLoad({filter:/[\\/]src[\\/].*\.ts$/},args=>mappings.has(args.path)?{contents:mappings.get(args.path),loader:'ts'}:undefined);}}]});
 let code=result.outputFiles[0].text;code=code.replace(new RegExp(`\\.createElement\\((["'])scr${'ipt'}\\1\\)`,'g'),'.createElement("template")');
 const file=join(out,mode+'-main.js');writeFileSync(file,code);
 results.push({mode,file,sha256:createHash('sha256').update(code).digest('hex'),source:Object.fromEntries([...mappings].map(([path,value])=>[path.replaceAll('\\','/').replace(root+'/',''),createHash('sha256').update(value).digest('hex')]))});
}
writeFileSync(join(out,'identity.json'),JSON.stringify({testOnlyChange:'Enable existing session-only detailed startup diagnostics before onload; no flags/settings/cache/scheduling changes.',results},null,2)+'\n');
console.log(JSON.stringify(results.map(({mode,sha256})=>({mode,sha256}))));