"""Audit the final cleanup scope, archive coverage, immutable runtime sources and new doc links."""
import hashlib,json,os,pathlib,re,subprocess,zipfile
root=pathlib.Path(r'C:\Users\viczi\GitHub\kplex')
out=pathlib.Path(os.environ['TEMP'])/'kplex-pr153-final-verification'
def git(*args):
    """Read the exact repository diff/object without mutating worktree or index."""
    return subprocess.check_output(['git',*args],cwd=root)
archive=pathlib.Path(os.environ['TEMP'])/'kplex-pr153-final-evidence'/'remote-verified.zip'
with zipfile.ZipFile(archive) as z:
    manifest=json.loads(z.read('MANIFEST.json'))['files']
removed=git('diff','HEAD','--name-only','--diff-filter=D').decode().splitlines()
verified=[]
for path in removed:
    if path=='HANDOFF.md':
        continue
    fact=manifest['repository/'+path]
    assert fact['gitBlob']==git('rev-parse','HEAD:'+path).decode().strip(),path
    verified.append(path)
expected={
'src/index/GraphBuilder.ts':'8ff16a836940020bffc509ea9ed6213e9e3233bb1ed1f3fa2542bd2691da738b',
'src/index/GraphIndex.ts':'31a9d5fe615a7febf6b514d7c1233d956aa112305341d666944c0a0474fdaa37',
'src/index/UrlAdjacencyMap.ts':'375c260daf99de88004e1f18dac7d9f601ad998e2ee9d8c31af2a846c32800a4',
'src/index/IndexedDbCache.ts':'7f01d8791651aae70b0269e1131160dfa4fdad1b4a881baa9a727850d9f0af01',
'src/core/graph/compiler.ts':'ee403bd86870137e7ea769dfb5c5c7cfa27e08ad768b1815bef47eab9732bd4f',
'src/core/graph/evidence.ts':'8d85ac390ab586653d8b463ee9754f261e0cc89e45aa62b4457783395c6ddf6b'}
actual={path:hashlib.sha256((root/path).read_bytes()).hexdigest() for path in expected}
assert actual==expected,'Accepted production source hashes changed'
assert not git('diff','HEAD','--','src','tests','package.json').strip(),'Cleanup changes runtime/tests/registration'
base='df5335808aacfd6a11ac7ff4ef008f9406f27893'
assert not git('diff',base,'--','README.md','manifest.json','manifest-beta.json','styles.css','package-lock.json').strip(),'Unrelated release/readme/style/lock changes'
subprocess.check_call(['git','diff','--check'],cwd=root)
report=root/'docs/validation/indexing-performance-153-2026-10-14.md'
for doc in [report,root/'Refactor plan.md']:
    text=doc.read_text(encoding='utf8')
    if doc.name=='Refactor plan.md':text=text.split('### 2026-10-14 — PR #153 indexing performance closeout')[1]
    for target in re.findall(r'\]\(([^)]+)\)',text):
        if re.match(r'https?://',target):continue
        target=target.split('#')[0].replace('%20',' ')
        assert (doc.parent/target).exists(),(doc,target)
receipt={'status':'passed','sourceHead':git('rev-parse','HEAD').decode().strip(),'archivedRemovedFiles':len(verified),'handoffRemovedWithoutArchiving':not(root/'HANDOFF.md').exists(),'productionSources':actual,'runtimeTestsRegistrationUnchangedByCleanup':True,'releaseReadmeStyleLockUnchangedFromPRBase':True,'newLocalDocLinksValid':True,'whitespacePassed':True}
(out/'static-review.json').write_text(json.dumps(receipt,indent=2)+'\n',encoding='utf8')
print(json.dumps({key:value for key,value in receipt.items() if key!='productionSources'}))
