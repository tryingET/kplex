/** Run the unchanged full native lane plus foreground cases, preserving original disposable-vault state. */
import {spawnSync} from 'node:child_process';
import {readFileSync,writeFileSync,mkdirSync,openSync,closeSync} from 'node:fs';
import {join} from 'node:path';
import {createHash} from 'node:crypto';
import {obsidianCliExecutable,spawnNativeSync} from 'file:///C:/Users/viczi/GitHub/kplex/scripts/testing/obsidian/processTools.mjs';
const root='C:/Users/viczi/GitHub/kplex',out=join(process.env.TEMP,'kplex-pr153-final-verification');
mkdirSync(out,{recursive:true});
const vault='kplex-test-small',config='C:/Obsidian/kplex-test-small/.obsidian';
Object.assign(process.env,{KPLEX_TEST_VAULT_NAME:vault,KPLEX_TEST_VAULT_PATH:'C:/Obsidian/kplex-test-small',KPLEX_TEST_CONFIG_DIR:config});
const settings=join(config,'plugins/k-plex/data.json'),enabled=join(config,'community-plugins.json'),original=new Map([settings,enabled].map(path=>[path,readFileSync(path)]));
/** Execute only the named disposable vault's native command, preserving long eval transport. */
function cli(name,...args){const r=spawnNativeSync(obsidianCliExecutable(),[`vault=${vault}`,name,...args],{encoding:'utf8',timeout:30000,killSignal:'SIGKILL',maxBuffer:4*1024*1024});if(r.error||r.status!==0||/^Error:/m.test(r.stdout))throw Error(r.error?.message||r.stderr||r.stdout);return r.stdout.trim();}
/** Decode a JSON value returned by native eval without printing the captured workspace. */
function evaluate(code){const raw=cli('eval',`code=${code}`);return JSON.parse(raw.slice(raw.indexOf('{')));}
const receipt={startedAt:new Date().toISOString(),status:'failed',steps:[],limitations:['Windows native API/DOM, not macOS or physical mobile/paint/process-peak acceptance']};
let saved;
try{
  if(cli('vault','info=path').replace(/^path\s+/,'').replaceAll('\\','/')!=='C:/Obsidian/kplex-test-small')throw Error('Wrong disposable vault');
  saved=evaluate(`(()=>{const w=require('@electron/remote').getCurrentWindow();return JSON.stringify({layout:app.workspace.getLayout(),bounds:w.getBounds(),maximized:w.isMaximized(),minimized:w.isMinimized(),fullScreen:w.isFullScreen(),throttling:w.webContents.getBackgroundThrottling()})})()`);
  for(const [name,script] of [['full','scripts/testing/obsidian/verify.mjs'],['foreground','scripts/testing/obsidian/foreground.mjs']]){
    const log=join(out,`${name}.log`),report=join(out,name);mkdirSync(report,{recursive:true});
    process.env.KPLEX_HOST_REPORT_DIR=report;
    const fd=openSync(log,'w');let result;
    try{result=spawnSync(process.execPath,[script],{cwd:root,env:process.env,stdio:['ignore',fd,fd],timeout:40*60*1000,killSignal:'SIGKILL'});}finally{closeSync(fd);}
    receipt.steps.push({name,exitCode:result.status,error:result.error?.message,log,report});
    writeFileSync(join(out,'summary.json'),JSON.stringify(receipt,null,2)+'\n');
    console.log(`${name}: exit ${result.status}; log ${log}`);
    if(result.error||result.status!==0)throw Error(`${name} verification failed`);
  }
  receipt.status='passed';
}catch(error){receipt.error=String(error);}
finally{
  try{
    if(saved){
      const s=JSON.stringify(saved);
      const result=evaluate(`(async()=>{const s=${s},w=require('@electron/remote').getCurrentWindow();await app.workspace.changeLayout(s.layout);if(w.isFullScreen()!==s.fullScreen)w.setFullScreen(s.fullScreen);if(!s.maximized&&w.isMaximized())w.unmaximize();w.setBounds(s.bounds);if(s.maximized)w.maximize();if(s.minimized)w.minimize();if(w.webContents.getBackgroundThrottling()!==s.throttling)throw Error('Throttling changed');return JSON.stringify({restored:true,layoutMatches:JSON.stringify(app.workspace.getLayout())===JSON.stringify(s.layout)})})()`);
      if(!result.restored||!result.layoutMatches)throw Error('Original workspace restoration mismatch');
      receipt.workspaceRestored=true;receipt.throttlingPreserved=true;
    }
    for(const [path,bytes]of original){if(!readFileSync(path).equals(bytes))writeFileSync(path,bytes);if(!readFileSync(path).equals(bytes))throw Error('Configuration bytes mismatch');}
    receipt.configurationRestored=true;
    receipt.artifacts=Object.fromEntries(['main.js','manifest.json','styles.css'].map(name=>[name,createHash('sha256').update(readFileSync(join(root,'dist',name))).digest('hex')]));
  }catch(error){receipt.cleanupError=String(error);receipt.status='failed';}
  receipt.completedAt=new Date().toISOString();
  writeFileSync(join(out,'summary.json'),JSON.stringify(receipt,null,2)+'\n');
}
console.log(JSON.stringify(receipt));
if(receipt.status!=='passed')process.exitCode=1;
