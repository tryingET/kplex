# Final Linux CI

Complete GitHub Actions output and run/job identity for successful verification run 38599159952, source head e1d8ca63c33b9830313b3d7c5465ef2a096a03c8. The workflow runs npm ci and npm run verify on Ubuntu with Node 22.22.2 and real Chrome. The log contains the actual checkout/merge identity and full stdout/stderr. Native Windows full/foreground receipts are separate in final-verification.zip. This CI does not waive macOS, physical-mobile or longer-session acceptance. Verify using the adjacent verify-archive.py and outer SHA256SUMS.
